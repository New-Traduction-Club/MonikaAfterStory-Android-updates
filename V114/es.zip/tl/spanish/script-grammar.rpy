﻿
# game/script-grammar.rpy:65
translate spanish monika_gtod_tip000_5f6140e7:

    # m 3eub "Of course I'll teach you about grammar, [player]!"
    m 3eub "¡Claro que te enseñaré gramática, [player]!"

# game/script-grammar.rpy:66
translate spanish monika_gtod_tip000_0a281c45:

    # m 3hua "It makes me really happy you want to improve your writing skills."
    m 3hua "Me hace mucha ilusión que quieras mejorar tus habilidades de escritura."

# game/script-grammar.rpy:67
translate spanish monika_gtod_tip000_0eaadf4a:

    # m 1eub "I've actually been reviewing some books on writing, and I think there are some interesting things we can talk about!"
    m 1eub "De hecho, he estado repasando algunos libros sobre escritura, ¡y creo que hay algunas cosas interesantes de las que podemos hablar!"

# game/script-grammar.rpy:68
translate spanish monika_gtod_tip000_d9d80217:

    # m 1rksdla "I'll admit...{w=0.5}it kind of sounds strange to discuss something as specific as grammar."
    m 1rksdla "Reconozco que...{w=0.5} suena un poco raro hablar de algo tan específico como la gramática."

# game/script-grammar.rpy:69
translate spanish monika_gtod_tip000_e17ef418:

    # m 1rksdlc "I know it's not the most exciting thing that comes up in people's minds."
    m 1rksdlc "Sé que no es el tema más apasionante del mundo ni lo primero que se te pasa por la cabeza."

# game/script-grammar.rpy:70
translate spanish monika_gtod_tip000_f86044a6:

    # m 3eksdld "...Maybe you think of strict teachers, or stuck-up editors..."
    m 3eksdld "... Quizás pienses en profesores estrictos o editores estirados..."

# game/script-grammar.rpy:71
translate spanish monika_gtod_tip000_7179ab84:

    # m 3eka "But I think that there's a certain beauty in mastering how you write and eloquently delivering your message."
    m 3eka "Pero creo que hay cierta belleza en dominar cómo escribes y transmitir tu mensaje con elocuencia."

# game/script-grammar.rpy:72
translate spanish monika_gtod_tip000_a6bfbf14:

    # m 1eub "So{w=0.5}starting today, I'll be sharing Monika's Grammar Tip of the Day!"
    m 1eub "Así que...{w=0.5} ¡a partir de hoy compartiré el Consejo de Gramática del Día de Monika!"

# game/script-grammar.rpy:73
translate spanish monika_gtod_tip000_76c4d53f:

    # m 1hua "Let's improve our writing together, [mas_get_player_nickname()]~"
    m 1hua "Mejoremos nuestra escritura junt[end_letter_gender]s, [mas_get_player_nickname()]."

# game/script-grammar.rpy:74
translate spanish monika_gtod_tip000_346e1173:

    # m 3eub "We'll start with clauses, the basic building blocks of sentences!"
    m 3eub "¡Empezaremos con las oraciones, los bloques básicos que forman las frases!"

# game/script-grammar.rpy:102
translate spanish monika_gtod_tip001_5d507ca3:

    # m 3eud "You probably know this already, but a clause is a group of words that has a subject and an action, or predicate."
    m 3eud "Probablemente ya sepas esto, pero una cláusula es un grupo de palabras que tiene un sujeto y una acción, o predicado."

# game/script-grammar.rpy:103
translate spanish monika_gtod_tip001_172bf38d:

    # m 1euc "For the most part, clauses can be sorted into either independent or dependent clauses."
    m 1euc "Por lo general, las cláusulas se pueden clasificar en independientes o dependientes."

# game/script-grammar.rpy:104
translate spanish monika_gtod_tip001_bf730d17:

    # m 1esd "Independent clauses can stand on their own as sentences, such as in the sentence '{b}I wrote that.{/b}'"
    m 1esd "Las cláusulas independientes pueden sostenerse por sí mismas como oraciones, como en la frase '{b}Yo escribí eso.{/b}'"

# game/script-grammar.rpy:105
translate spanish monika_gtod_tip001_6b8ceb9e:

    # m 3euc "Dependent clauses, on the other hand, can't stand on their own and usually appear as parts of longer sentences."
    m 3euc "Las cláusulas dependientes, por otro lado, no pueden sostenerse por sí solas y suelen aparecer como partes de frases más largas."

# game/script-grammar.rpy:106
translate spanish monika_gtod_tip001_06218e97:

    # m 3eua "An example of one could be '{b}who saved her.{/b}'"
    m 3eua "Un ejemplo de una podría ser '{b}quien la salvó.{/b}'"

# game/script-grammar.rpy:107
translate spanish monika_gtod_tip001_8da3746c:

    # m 3eud "There's a subject, '{b}who{/b},' and an action, '{b}saved her{/b},' but of course, the clause can't be a sentence by itself."
    m 3eud "Hay un sujeto, '{b}quien{/b}', y una acción, '{b}la salvó{/b}', pero por supuesto, la cláusula no puede ser una frase por sí misma."

# game/script-grammar.rpy:108
translate spanish monika_gtod_tip001_a60a5771:

    # m 1ekbsa "{w=0.5}I think you know how to finish that sentence, [player]~"
    m 1ekbsa "...{w=0.5} Creo que sabes cómo terminar esa frase, [player]."

# game/script-grammar.rpy:109
translate spanish monika_gtod_tip001_9e212a5e:

    # m 3eub "Okay, that's all for today's lesson. Thanks for listening!"
    m 3eub "Vale, eso es todo por la lección de hoy. ¡Gracias por escuchar!"

# game/script-grammar.rpy:131
translate spanish monika_gtod_tip002_e5cdb645:

    # m 1eua "Do you remember when we talked about clauses, [player]?"
    m 1eua "¿Recuerdas cuando hablamos de las cláusulas, [player]?"

# game/script-grammar.rpy:132
translate spanish monika_gtod_tip002_c58a1154:

    # m 1eud "There's actually a very common mistake that many writers fall into when joining them."
    m 1eud "De hecho, hay un error muy común que cometen muchos escritores al unirlas."

# game/script-grammar.rpy:133
translate spanish monika_gtod_tip002_60f390db:

    # m 3esc "When you join two independent clauses together, this is called a comma splice."
    m 3esc "Cuando unes dos oraciones independientes solo con una coma, cometes un error que en inglés llamamos 'comma splice' o empalme por comas."

# game/script-grammar.rpy:134
translate spanish monika_gtod_tip002_06ce347c:

    # m 3esa "Here's an example:{w=0.5} '{b}I visited the park, I looked at the sky, I saw many stars.{/b}"
    m 3esa "Aquí hay un ejemplo:{w=0.5} '{b}Visité el parque, miré al cielo, vi muchas estrellas.{/b}'"

# game/script-grammar.rpy:135
translate spanish monika_gtod_tip002_e037ba6c:

    # m 1eua "This doesn't seem like a problem at first, but you could imagine adding more and more clauses to that sentence..."
    m 1eua "Esto no parece un problema al principio, pero imagínate añadiendo más y más cláusulas a esa frase..."

# game/script-grammar.rpy:136
translate spanish monika_gtod_tip002_57fc77c7:

    # m 3wud "The result would be a mess!"
    m 3wud "¡El resultado sería un desastre!"

# game/script-grammar.rpy:137
translate spanish monika_gtod_tip002_07a5b69f:

    # m 1esd "'{b}I visited the park, I looked at the sky, I saw many stars, I saw some constellations, one of them looked like a crab{/b}...'{w=0.5} It could go on and on."
    m 1esd "'{b}Visité el parque, miré al cielo, vi muchas estrellas, vi algunas constelaciones, una de ellas parecía un cangrejo{/b}...' Podría seguir y seguir."

# game/script-grammar.rpy:138
translate spanish monika_gtod_tip002_409448ae:

    # m 1eua "The best way to avoid this mistake is to separate independent clauses with periods, conjunctions, or semicolons."
    m 1eua "La mejor forma de evitar este error es separar las cláusulas independientes con puntos, conjunciones o puntos y coma."

# game/script-grammar.rpy:139
translate spanish monika_gtod_tip002_006ca88f:

    # m 1eud "A conjunction is basically a word that you use to connect two clauses or phrases together."
    m 1eud "Una conjunción es básicamente una palabra que usas para conectar dos cláusulas o frases entre sí."

# game/script-grammar.rpy:140
translate spanish monika_gtod_tip002_8fc502d8:

    # m 3eub "They're a pretty interesting topic on their own, so we can go over them in a future tip!"
    m 3eub "Las conjunciones son un tema bastante interesante por sí solas, ¡así que podemos repasarlas en un futuro consejo!"

# game/script-grammar.rpy:141
translate spanish monika_gtod_tip002_744c1fef:

    # m 3eud "Anyway, taking that example we had earlier, let's add a conjunction and a period to make our sentence flow better..."
    m 3eud "En fin, tomando ese ejemplo que teníamos antes, añadamos una conjunción y un punto para hacer que nuestra frase fluya mejor..."

# game/script-grammar.rpy:142
translate spanish monika_gtod_tip002_3f78e71a:

    # m 1eud "'{b}I visited the park, and I looked at the sky. I saw many stars.{/b}'"
    m 1eud "'{b}Visité el parque y miré al cielo. Vi muchas estrellas.{/b}'"

# game/script-grammar.rpy:143
translate spanish monika_gtod_tip002_ccd93aa6:

    # m 3hua "Much better, don't you think?"
    m 3hua "Mucho mejor, ¿no crees?"

# game/script-grammar.rpy:144
translate spanish monika_gtod_tip002_396c74f9:

    # m 1eub "That's all I have for today, [player]."
    m 1eub "Eso es todo lo que tengo por hoy, [player]."

# game/script-grammar.rpy:145
translate spanish monika_gtod_tip002_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

# game/script-grammar.rpy:167
translate spanish monika_gtod_tip003_bb5572e8:

    # m 1eub "Okay, [player]! I think it's time we talk about...{w=0.5}conjunctions!"
    m 1eub "¡Vale, [player]! Creo que es hora de que hablemos de...{w=0.5} ¡las conjunciones!"

# game/script-grammar.rpy:168
translate spanish monika_gtod_tip003_5cd11ef5:

    # m 3esa "Like I said before, conjunctions are words or phrases that bring two ideas together."
    m 3esa "Como dije antes, las conjunciones son palabras o frases que unen dos ideas."

# game/script-grammar.rpy:169
translate spanish monika_gtod_tip003_f12ce9f6:

    # m 3wud "When you think about it, that's a big category! There are so many words we use to accomplish that."
    m 3wud "Si te paras a pensarlo, ¡es una categoría enorme! Hay muchísimas palabras que usamos para lograr eso."

# game/script-grammar.rpy:170
translate spanish monika_gtod_tip003_53406bf6:

    # m 1euc "Just imagine speaking without conjunctions..."
    m 1euc "Solo imagínate hablar sin conjunciones..."

# game/script-grammar.rpy:171
translate spanish monika_gtod_tip003_556b6161:

    # m 1esc "It would be dull.{w=0.3} You would sound choppy.{w=0.3} These ideas all relate.{w=0.3} We should connect them."
    m 1esc "Sería aburrido.{w=0.3} Sonarías muy entrecortad[end_letter_gender].{w=0.3} Estas ideas están relacionadas.{w=0.3} Deberíamos conectarlas."

# game/script-grammar.rpy:172
translate spanish monika_gtod_tip003_3d85a4fa:

    # m 3eua "As you will see, conjunctions are great for combining ideas, and at the same time, they make your writing sound fluid and more similar to how we actually talk."
    m 3eua "Como verás, las conjunciones son geniales para combinar ideas, y al mismo tiempo, hacen que tu escritura suene fluida y más similar a como hablamos realmente."

# game/script-grammar.rpy:173
translate spanish monika_gtod_tip003_fbcbfc8b:

    # m 1eua "Now, let's revisit our earlier example, this time with conjunctions..."
    m 1eua "Ahora, volvamos a nuestro ejemplo anterior, esta vez con conjunciones..."

# game/script-grammar.rpy:174
translate spanish monika_gtod_tip003_f358b883:

    # m 1eub "'{b}It would be dull, and you would sound choppy. Since these ideas all relate, we should connect them.{/b}'"
    m 1eub "'{b}Sería aburrido y sonarías entrecortad[end_letter_gender]. Ya que estas ideas se relacionan, deberíamos conectarlas.{/b}'"

# game/script-grammar.rpy:175
translate spanish monika_gtod_tip003_ccd93aa6:

    # m 3hua "Much better, don't you think?"
    m 3hua "Mucho mejor, ¿no crees?"

# game/script-grammar.rpy:176
translate spanish monika_gtod_tip003_4eaeaac2:

    # m 1esa "Anyway, there are three types of conjunctions:{w=0.5} coordinating, correlative, and subordinating."
    m 1esa "En fin, hay tres tipos de conjunciones:{w=0.5} coordinantes, correlativas y subordinantes."

# game/script-grammar.rpy:177
translate spanish monika_gtod_tip003_9702fc83:

    # m 1hksdla "Their names may sound a little daunting, but I promise they'll make more sense as we go through them. I'll give you examples as we go along."
    m 1hksdla "Sus nombres pueden sonar un poco intimidantes, pero prometo que tendrán más sentido a medida que los repasemos. Te daré ejemplos sobre la marcha."

# game/script-grammar.rpy:178
translate spanish monika_gtod_tip003_6f3539a7:

    # m 1esd "Coordinating clauses bridge two words, phrases, or clauses of the same 'rank' together. This just means that they have to be of the same type...words with words, or clauses with clauses."
    m 1esd "Las conjunciones coordinantes unen dos palabras, frases o cláusulas del mismo 'rango'. Esto solo significa que tienen que ser del mismo tipo... palabras con palabras, o cláusulas con cláusulas."

# game/script-grammar.rpy:179
translate spanish monika_gtod_tip003_9d9bcfb0:

    # m 3euc "Some common examples include:{w=0.5} '{b}and{/b},' '{b}or{/b},' '{b}but{/b},' '{b}so{/b},' and '{b}yet{/b}.'"
    m 3euc "Algunos ejemplos comunes son:{w=0.5} '{b}y{/b}', '{b}o{/b}', '{b}pero{/b}', '{b}así que{/b}' y '{b}sin embargo{/b}'."

# game/script-grammar.rpy:180
translate spanish monika_gtod_tip003_d0b53c4e:

    # m 3eub "You can connect independent clauses, {i}and{/i} you can avoid comma splices!"
    m 3eub "¡Puedes conectar cláusulas independientes «y» evitar los empalmes por coma al mismo tiempo!"

# game/script-grammar.rpy:181
translate spanish monika_gtod_tip003_afde57de:

    # m 1esd "Correlative conjunctions are pairs of conjunctions used to connect ideas."
    m 1esd "Las conjunciones correlativas son pares de conjunciones que se usan para conectar ideas."

# game/script-grammar.rpy:182
translate spanish monika_gtod_tip003_3de0321e:

    # m 3euc "A few common pairs are:{w=0.5} '{b}either{/b}/{b}or{/b},' '{b}both{/b}/{b}and{/b},' and '{b}whether{/b}/{b}or{/b}.'"
    m 3euc "Algunos pares comunes son:{w=0.5} '{b}o{/b}... {b}o{/b}', '{b}tanto{/b}... {b}como{/b}' y '{b}ya sea{/b}... {b}o{/b}'."

# game/script-grammar.rpy:183
translate spanish monika_gtod_tip003_9207a50b:

    # m 3eub "{i}Whether{/i} you realize it {i}or{/i} not, we use them all the time...like in this sentence!"
    m 3eub "Tanto si te das cuenta como si no, las usamos a todas horas... ¡Como en esta frase!"

# game/script-grammar.rpy:184
translate spanish monika_gtod_tip003_7ff84e9b:

    # m 1esd "Lastly, subordinating conjunctions bring together independent and dependent clauses."
    m 1esd "Por último, las conjunciones subordinantes unen cláusulas independientes y dependientes."

# game/script-grammar.rpy:185
translate spanish monika_gtod_tip003_f82c4aeb:

    # m 3eub "As you can imagine, there are many ways we can do that!"
    m 3eub "Como te puedes imaginar, ¡hay muchas formas de hacer eso!"

# game/script-grammar.rpy:186
translate spanish monika_gtod_tip003_b588f215:

    # m 3euc "Examples include:{w=0.5} '{b}although{/b},' '{b}until{/b},' '{b}since{/b},' '{b}while{/b},' and '{b}as long as{/b}.'"
    m 3euc "Algunos ejemplos incluyen:{w=0.5} '{b}aunque{/b}', '{b}hasta que{/b}', '{b}ya que{/b}', '{b}mientras{/b}' y '{b}siempre que{/b}'."

# game/script-grammar.rpy:187
translate spanish monika_gtod_tip003_426a0c7b:

    # m 3eub "{i}Since{/i} there are so many, this category of conjunctions is the widest!"
    m 3eub "'Ya que' hay tantas, ¡esta categoría de conjunciones es la más amplia!"

# game/script-grammar.rpy:188
translate spanish monika_gtod_tip003_fe33df71:

    # m 3tsd "Oh, and another thing...{w=0.5} A pretty common misconception is that you shouldn't begin sentences with conjunctions."
    m 3tsd "Ah, y otra cosa...{w=0.5} Una idea errónea bastante común es que no se deben empezar las frases con conjunciones."

# game/script-grammar.rpy:189
translate spanish monika_gtod_tip003_04da8314:

    # m 3hub "As I just showed you with the last two examples, you definitely can, ahaha!"
    m 3hub "Como te acabo de mostrar con los dos últimos ejemplos, claro que puedes, ¡ja, ja, ja!"

# game/script-grammar.rpy:190
translate spanish monika_gtod_tip003_509682de:

    # m 1rksdla "But just avoid going overboard with them. Or else you sound a little forced."
    m 1rksdla "Pero evita excederte con ellas. O si no sonarás un poco forzad[end_letter_gender]."

# game/script-grammar.rpy:191
translate spanish monika_gtod_tip003_4f8ac4f8:

    # m 1eub "I think that's enough for today, [player]."
    m 1eub "Creo que es suficiente por hoy, [player]."

# game/script-grammar.rpy:192
translate spanish monika_gtod_tip003_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

# game/script-grammar.rpy:214
translate spanish monika_gtod_tip004_f547decc:

    # m 1eua "Today we will talk about a rarely used and commonly misunderstood punctuation mark..."
    m 1eua "Hoy hablaremos de un signo de puntuación poco utilizado y a menudo malentendido..."

# game/script-grammar.rpy:215
translate spanish monika_gtod_tip004_043797a9:

    # m 3eub "The semicolon!"
    m 3eub "¡El punto y coma!"

# game/script-grammar.rpy:216
translate spanish monika_gtod_tip004_8a0059ee:

    # m 3eua "Some interesting things have been written about semicolons, including this from the author Lewis Thomas..."
    m 3eua "Se han escrito cosas interesantes sobre el punto y coma, incluyendo esto del autor Lewis Thomas..."

# game/script-grammar.rpy:217
translate spanish monika_gtod_tip004_2fc293c1:

    # m 1esd "'{i}Sometimes you get a glimpse of a semicolon coming, a few lines farther on, and it is like climbing a steep path through woods and seeing a wooden bench just at a bend in the road ahead{/i}...'"
    m 1esd "'{i}A veces vislumbras un punto y coma acercándose, unas líneas más adelante, y es como subir un camino empinado por el bosque y ver un banco de madera justo en una curva del camino{/i}...'"

# game/script-grammar.rpy:218
translate spanish monika_gtod_tip004_d52e791f:

    # m 1esa "'{i}...a place where you can expect to sit for a moment, catching your breath.{/i}'"
    m 1esa "'{i}... un lugar donde puedes esperar sentarte un momento, recuperando el aliento.{/i}'"

# game/script-grammar.rpy:219
translate spanish monika_gtod_tip004_c3ec5b77:

    # m 1hua "I really appreciate how eloquently he describes something as simple as a punctuation mark!"
    m 1hua "¡Me encanta la elocuencia con la que describe algo tan simple como un signo de puntuación!"

# game/script-grammar.rpy:220
translate spanish monika_gtod_tip004_41a0edd1:

    # m 1euc "Some people think you can use a semicolon as a substitute for a colon, while others treat it as a period..."
    m 1euc "Algunas personas piensan que pueden usar el punto y coma como sustituto de los dos puntos, mientras que otras lo tratan como un punto..."

# game/script-grammar.rpy:221
translate spanish monika_gtod_tip004_30fe1720:

    # m 1esd "If you recall our talk on clauses, the semicolon is actually meant to connect two independent clauses."
    m 1esd "Si recuerdas nuestra charla sobre las cláusulas, el punto y coma en realidad sirve para conectar dos cláusulas independientes."

# game/script-grammar.rpy:222
translate spanish monika_gtod_tip004_29565698:

    # m 3euc "For example, if I wanted to keep two ideas together, such as '{b}You're here{/b}' and '{b}I'm happy{/b},' I could write them as..."
    m 3euc "Por ejemplo, si quisiera mantener dos ideas juntas, como '{b}Estás aquí{/b}' y '{b}Soy feliz{/b}', podría escribirlas como..."

# game/script-grammar.rpy:223
translate spanish monika_gtod_tip004_3a2c6f52:

    # m 3eud "'{b}You're here; I'm happy{/b}' instead of '{b}You're here, and I'm happy{/b}' or '{b}You're here. I'm happy{/b}.'"
    m 3eud "'{b}Estás aquí; soy feliz{/b}' en lugar de '{b}Estás aquí y soy feliz{/b}' o '{b}Estás aquí. Soy feliz.{/b}'"

# game/script-grammar.rpy:224
translate spanish monika_gtod_tip004_53d4afb0:

    # m 1eub "All three sentences convey the same message, but in comparison, '{b}You're here; I'm happy{/b}' connects the two clauses at a happy medium."
    m 1eub "Las tres frases transmiten el mismo mensaje, pero en comparación, '{b}Estás aquí; soy feliz{/b}' conecta las dos cláusulas en un punto medio."

# game/script-grammar.rpy:225
translate spanish monika_gtod_tip004_977aae40:

    # m 1esa "In the end, this always depends on the ideas you want to connect, but I think that Thomas puts it well when you compare them to periods or commas."
    m 1esa "Al final, esto siempre depende de las ideas que quieras conectar, pero creo que Thomas lo expresa bien cuando las compara con puntos o comas."

# game/script-grammar.rpy:226
translate spanish monika_gtod_tip004_139c8635:

    # m 1eud "Unlike a period, which opens up to a completely different sentence, or a comma, which shows you there is more to come in the same one..."
    m 1eud "A diferencia de un punto, que da paso a una frase completamente diferente, o una coma, que te indica que la oración aún no ha terminado..."

# game/script-grammar.rpy:227
translate spanish monika_gtod_tip004_16d6f0d8:

    # m 3eub "A semicolon really is that in-between, or, as Thomas says, '{i}a place where you can expect to sit for a moment and catch your breath.{/i}'"
    m 3eub "Un punto y coma es realmente ese punto intermedio, o, como dice Thomas, '{i}un lugar donde puedes esperar sentarte un momento y recuperar el aliento.{/i}'"

# game/script-grammar.rpy:228
translate spanish monika_gtod_tip004_1c980485:

    # m 1esa "At least this gives you a whole other option; hopefully, you can now make better use of the semicolon when you're writing..."
    m 1esa "Al menos esto te da otra opción totalmente distinta; con suerte, ahora podrás aprovechar mejor el punto y coma cuando escribas..."

# game/script-grammar.rpy:229
translate spanish monika_gtod_tip004_d6e406aa:

    # m 1hua "Ehehe."
    m 1hua "Je, je, je."

# game/script-grammar.rpy:230
translate spanish monika_gtod_tip004_6cd357ef:

    # m 1eub "Okay, that's enough for today, [player]."
    m 1eub "Vale, eso es suficiente por hoy, [player]."

# game/script-grammar.rpy:231
translate spanish monika_gtod_tip004_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

# game/script-grammar.rpy:253
translate spanish monika_gtod_tip005_75522dfe:

    # m 1eua "Today we'll talk about subjects and objects, [player]."
    m 1eua "Hoy hablaremos de sujetos y objetos, [player]."

# game/script-grammar.rpy:254
translate spanish monika_gtod_tip005_0657058c:

    # m 1eud "Remember when I told you about clauses having an action and a verb?"
    m 1eud "¿Recuerdas cuando te dije que las cláusulas tenían una acción y un verbo?"

# game/script-grammar.rpy:255
translate spanish monika_gtod_tip005_37eef0be:

    # m 3eub "The object is the person or thing that the subject acts on!"
    m 3eub "¡El objeto es la persona o cosa sobre la que actúa el sujeto!"

# game/script-grammar.rpy:256
translate spanish monika_gtod_tip005_1c3ad591:

    # m 1eua "So, in the sentence '{b}We watched the fireworks together{/b},' the object would be...{w=0.5}the '{b}fireworks{/b}.'"
    m 1eua "Así que, en la frase '{b}Vimos los fuegos artificiales juntos{/b}', el objeto serían... {w=0.5}los '{b}fuegos artificiales{/b}'."

# game/script-grammar.rpy:257
translate spanish monika_gtod_tip005_e8437802:

    # m 3esd "Oh, it's important to note that objects aren't necessary to form complete sentences..."
    m 3esd "Ah, es importante señalar que los objetos no son necesarios para formar frases completas..."

# game/script-grammar.rpy:258
translate spanish monika_gtod_tip005_e050720d:

    # m 1eua "The sentence could very well have been, '{b}We watched.{/b}'"
    m 1eua "La frase podría haber sido perfectamente: '{b}Vimos.{/b}'"

# game/script-grammar.rpy:259
translate spanish monika_gtod_tip005_c1706c03:

    # m 3hksdlb "That's a complete sentence...although it's an ambiguous one, ahaha!"
    m 3hksdlb "Esa es una frase completa... aunque es ambigua, ¡ja, ja, ja!"

# game/script-grammar.rpy:260
translate spanish monika_gtod_tip005_089c18e9:

    # m 1eud "There's also nothing that says that the object has to come last, but I'll discuss that in more detail another time."
    m 1eud "Tampoco hay nada que diga que el objeto tiene que ir al final, pero hablaré de eso con más detalle en otra ocasión."

# game/script-grammar.rpy:261
translate spanish monika_gtod_tip005_701c3d0d:

    # m 3esa "Just remember that the subject is doing the action and the object is acted upon."
    m 3esa "Solo recuerda que el sujeto hace la acción y el objeto recibe la acción."

# game/script-grammar.rpy:262
translate spanish monika_gtod_tip005_469c14cb:

    # m 1eub "Okay, that's all for today..."
    m 1eub "Vale, eso es todo por hoy..."

# game/script-grammar.rpy:263
translate spanish monika_gtod_tip005_6f3fed75:

    # m 3hub "Thanks for listening, [player]! I love."
    m 3hub "¡Gracias por escuchar, [player]! Te..."

# game/script-grammar.rpy:264
translate spanish monika_gtod_tip005_23a3b2db:

    # m 1eua "..."
    m 1eua "..."

# game/script-grammar.rpy:265
translate spanish monika_gtod_tip005_f5b8d6cd:

    # m 1tuu "..."
    m 1tuu "..."

# game/script-grammar.rpy:266
translate spanish monika_gtod_tip005_38f81bbf:

    # m 3hub "You!"
    m 3hub "¡... quiero!"

# game/script-grammar.rpy:288
translate spanish monika_gtod_tip006_a9233158:

    # m 1eud "[player], do you know about voices in writing?"
    m 1eud "[player], ¿sabes sobre las voces en la escritura?"

# game/script-grammar.rpy:289
translate spanish monika_gtod_tip006_7c86cc90:

    # m 3eua "There's the active voice and the passive voice."
    m 3eua "Existen la voz activa y la voz pasiva."

# game/script-grammar.rpy:290
translate spanish monika_gtod_tip006_900cb535:

    # m 3euc "If you remember our talk on subjects and objects, the big difference between the two voices is whether the subject or the object comes first."
    m 3euc "Si recuerdas nuestra charla sobre sujetos y objetos, la gran diferencia entre las dos voces es si el sujeto o el objeto van primero."

# game/script-grammar.rpy:291
translate spanish monika_gtod_tip006_29631c65:

    # m 1esd "Let's say the subject is '{b}Sayori{/b}' and the object is a '{b}cupcake{/b}.'"
    m 1esd "Digamos que el sujeto es '{b}Sayori{/b}' y el objeto es un '{b}cupcake{/b}'."

# game/script-grammar.rpy:292
translate spanish monika_gtod_tip006_dcb1ce79:

    # m 3eud "Here's the sentence in an active voice:{w=0.5} '{b}Sayori ate the last cupcake.{/b}'"
    m 3eud "Aquí está la frase en voz activa:{w=0.5} '{b}Sayori se comió el último cupcake.{/b}'"

# game/script-grammar.rpy:293
translate spanish monika_gtod_tip006_238b8f4a:

    # m 3euc "Here it is again in a passive voice:{w=0.5} '{b}The last cupcake was eaten.{/b}'"
    m 3euc "Aquí está de nuevo en voz pasiva:{w=0.5} '{b}El último cupcake fue devorado.{/b}'"

# game/script-grammar.rpy:294
translate spanish monika_gtod_tip006_72c373e9:

    # m 1eub "As you can see, you can use the passive voice to be secretive about the subject yet still have a complete sentence."
    m 1eub "Como puedes ver, la voz pasiva te permite ocultar quién es el sujeto y, aun así, tener una frase completa."

# game/script-grammar.rpy:295
translate spanish monika_gtod_tip006_4a7ad033:

    # m 1tuu "It's true; you {i}can{/i} use the passive voice to be sneaky!{w=0.5} It does have other uses, though."
    m 1tuu "Es cierto; ¡puedes usar la voz pasiva para ser más sutil!{w=0.5} Sin embargo, tiene otros usos."

# game/script-grammar.rpy:296
translate spanish monika_gtod_tip006_b2a719e1:

    # m 3esd "For example, in some careers, people have to use the passive voice to be impersonal."
    m 3esd "Por ejemplo, en algunas profesiones, la gente tiene que usar la voz pasiva para ser impersonal."

# game/script-grammar.rpy:297
translate spanish monika_gtod_tip006_df980cd9:

    # m 3euc "Scientists describe experiments with '{b}the results were documented{/b}...' since the important part is their work and not who did it."
    m 3euc "Los científicos describen experimentos con '{b}los resultados fueron documentados{/b}...' ya que la parte importante es su trabajo y no quién lo hizo."

# game/script-grammar.rpy:298
translate spanish monika_gtod_tip006_2d619292:

    # m 1esa "Anyway, for the most part, stick with the active voice for readability and, you know, to directly tell who's doing what."
    m 1esa "En fin, por lo general, quédate con la voz activa para facilitar la lectura y, ya sabes, para decir directamente quién hace qué."

# game/script-grammar.rpy:299
translate spanish monika_gtod_tip006_4f8ac4f8:

    # m 1eub "I think that's enough for today, [player]."
    m 1eub "Creo que es suficiente por hoy, [player]."

# game/script-grammar.rpy:300
translate spanish monika_gtod_tip006_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

# game/script-grammar.rpy:322
translate spanish monika_gtod_tip007_2f011a3b:

    # m 1eua "Today we will talk about the uses of '{b}who{/b}' and '{b}whom{/b}.'"
    m 1eua "Hoy hablaremos de los pronombres '{b}quien{/b}' y '{b}a quien{/b}'."

# game/script-grammar.rpy:323
translate spanish monika_gtod_tip007_a800a06e:

    # m 3hub "Most of the time, it seems like people just use '{b}who{/b}' without bothering to learn the difference, ahaha."
    m 3hub "La mayoría de las veces, parece que la gente usa simplemente '{b}quien{/b}' sin molestarse en aprender la diferencia, ¡ja, ja, ja!"

# game/script-grammar.rpy:324
translate spanish monika_gtod_tip007_6a6aa8a8:

    # m 1esd "The difference is that '{b}who{/b}' refers to a subject, and '{b}whom{/b}' refers to an object."
    m 1esd "La diferencia es que '{b}quien{/b}' se refiere a un sujeto, y '{b}a quien{/b}' se refiere a un objeto."

# game/script-grammar.rpy:325
translate spanish monika_gtod_tip007_bde71521:

    # m 3eub "It turns out that it's pretty easy to figure out when to use one or the other!"
    m 3eub "¡Resulta que es bastante fácil averiguar cuándo usar uno u otro!"

# game/script-grammar.rpy:326
translate spanish monika_gtod_tip007_f12d9e50:

    # m 1euc "'{b}Who{/b}' corresponds to '{b}he{/b}/{b}she{/b}/{b}they{/b}' while '{b}whom{/b}' corresponds to '{b}him{/b}/{b}her{/b}/{b}them{/b}.'"
    m 1euc "'{b}Quien{/b}' corresponde a '{b}él{/b}', '{b}ella{/b}' o '{b}ellos{/b}', mientras que '{b}a quien{/b}' corresponde a '{b}a él{/b}', '{b}a ella{/b}' o '{b}a ellos{/b}'."

# game/script-grammar.rpy:327
translate spanish monika_gtod_tip007_c8a67776:

    # m 3eud "Simply replace the possible '{b}who{/b}' or '{b}whom{/b}' with '{b}he{/b}/{b}she{/b}/{b}they{/b}' or '{b}him{/b}/{b}her{/b}/{b}them{/b}.'"
    m 3eud "Simplemente reemplaza el posible '{b}quien{/b}' o '{b}a quien{/b}' por '{b}él{/b}/{b}ella{/b}' o '{b}a él{/b}/{b}a ella{/b}'."

# game/script-grammar.rpy:328
translate spanish monika_gtod_tip007_d7e1b90c:

    # m 1eua "Only one replacement should make sense, and that should tell you which one to use!"
    m 1eua "¡Solo un reemplazo debería tener sentido, y eso debería decirte cuál usar!"

# game/script-grammar.rpy:329
translate spanish monika_gtod_tip007_f2caf116:

    # m 3eua "Let's take, for example, the title of my poem, {i}The Lady who Knows Everything{/i}."
    m 3eua "Tomemos, por ejemplo, el título de mi poema, {i}The Lady who Knows Everything{/i}."

# game/script-grammar.rpy:330
translate spanish monika_gtod_tip007_4954852b:

    # m 3esd "If we just look at the clause '{b}who knows everything{/b}' and replace the '{b}who{/b},' we get..."
    m 3esd "Si solo miramos la cláusula '{b}quien lo sabe todo{/b}' y reemplazamos el '{b}quien{/b}', obtenemos..."

# game/script-grammar.rpy:331
translate spanish monika_gtod_tip007_3332c9de:

    # m 1esd "'{b}She knows everything{/b}' or '{b}her knows everything{/b}.'"
    m 1esd "'{b}Ella lo sabe todo{/b}' o '{b}a ella lo sabe todo{/b}'."

# game/script-grammar.rpy:332
translate spanish monika_gtod_tip007_98795251:

    # m 3euc "Only '{b}she knows everything{/b}' makes sense, so the correct phrase is '{b}who knows everything{/b}.'"
    m 3euc "Como notarás, solo '{b}ella lo sabe todo{/b}' tiene sentido, así que la frase correcta usa '{b}quien{/b}'."

# game/script-grammar.rpy:333
translate spanish monika_gtod_tip007_28e0370d:

    # m 1hksdla "Who said writing was hard?"
    m 1hksdla "¿Quién dijo que escribir era difícil?"

# game/script-grammar.rpy:334
translate spanish monika_gtod_tip007_396c74f9:

    # m 1eub "That's all I have for today, [player]."
    m 1eub "Eso es todo lo que tengo por hoy, [player]."

# game/script-grammar.rpy:335
translate spanish monika_gtod_tip007_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

# game/script-grammar.rpy:357
translate spanish monika_gtod_tip008_c75d9b1e:

    # m 1eua "Last time, we talked about the difference between '{b}who{/b}' and '{b}whom{/b}.'"
    m 1eua "La última vez hablamos de la diferencia entre '{b}who{/b}' y '{b}whom{/b}'."

# game/script-grammar.rpy:358
translate spanish monika_gtod_tip008_c5d8852a:

    # m 1esd "Another couple of words that can be just as confusing to use are '{b}and I{/b}' and '{b}and me{/b}.'"
    m 1esd "Otro par de construcciones que pueden ser igual de confusas son '{b}y yo{/b}' e '{b}y a mí{/b}'."

# game/script-grammar.rpy:359
translate spanish monika_gtod_tip008_8f97b260:

    # m 3etc "Is it '{b}[player] and I went on a date{/b}' or '{b}[player] and me went on a date{/b}?'"
    m 3etc "¿Es '{b}[player] y yo fuimos a una cita{/b}' o '{b}[player] y a mí fuimos a una cita{/b}'?"

# game/script-grammar.rpy:360
translate spanish monika_gtod_tip008_9f5daca5:

    # m 3eud "Just like with '{b}who{/b}' and '{b}whom{/b},' the issue boils down to one of subjects and objects."
    m 3eud "Al igual que con '{b}who{/b}' y '{b}whom{/b}', todo depende de si son sujetos u objetos."

# game/script-grammar.rpy:361
translate spanish monika_gtod_tip008_c6aeaa47:

    # m 1esd "If the speaker is the subject of the sentence, '{b}and I{/b}' is correct."
    m 1esd "Si el hablante es el sujeto de la frase, '{b}and I{/b}' es lo correcto."

# game/script-grammar.rpy:362
translate spanish monika_gtod_tip008_0e297d78:

    # m 1euc "Conversely, if the speaker is the object of the sentence, '{b}and me{/b}' is correct."
    m 1euc "Por el contrario, si el hablante es el objeto de la frase, '{b}and me{/b}' es lo correcto."

# game/script-grammar.rpy:363
translate spanish monika_gtod_tip008_a0fefe9d:

    # m 3eub "Luckily, just like when we talked about '{b}who{/b}' versus '{b}whom{/b},' it turns out there's a simple way to figure out which one is correct!"
    m 3eub "Por suerte, igual que cuando hablamos de '{b}who{/b}' frente a '{b}whom{/b}', ¡resulta que hay una forma sencilla de averiguar cuál es la correcta!"

# game/script-grammar.rpy:364
translate spanish monika_gtod_tip008_04617b10:

    # m 1euc "In our example, if you just take out '{b}[player] and{/b}' from the sentence, only one should make sense."
    m 1euc "En nuestro ejemplo, si quitas '{b}[player] y{/b}' de la frase, solo una debería tener sentido."

# game/script-grammar.rpy:365
translate spanish monika_gtod_tip008_41948f3e:

    # m 1hua "Let's try it out!"
    m 1hua "¡Probémoslo!"

# game/script-grammar.rpy:366
translate spanish monika_gtod_tip008_dc037b2d:

    # m 3eud "The end result is:{w=0.5} '{b}I went on a date{/b}' or '{b}me went on a date{/b}.'"
    m 3eud "El resultado final es:{w=0.5} '{b}yo fui a una cita{/b}' o '{b}a mí fui a una cita{/b}'."

# game/script-grammar.rpy:367
translate spanish monika_gtod_tip008_6cdea02b:

    # m 3eub "Clearly, only the first one makes sense, so it's '{b}[player] and I went on a date{/b}.'"
    m 3eub "Claramente, solo la primera tiene sentido, así que lo correcto es '{b}[player] y yo fuimos a una cita{/b}'."

# game/script-grammar.rpy:368
translate spanish monika_gtod_tip008_8483b60f:

    # m 1tuu "Oh, sorry, [player]...{w=1}did it make you feel left out when I said only '{b}I went on a date{/b}?'"
    m 1tuu "Ah, lo siento, [player]...{w=1} ¿te hizo sentir excluid[end_letter_gender] cuando dije solo '{b}yo fui a una cita{/b}'?"

# game/script-grammar.rpy:369
translate spanish monika_gtod_tip008_7f7c7ece:

    # m 1hksdlb "Ahaha! Don't worry, I'd never leave you behind."
    m 1hksdlb "¡Ja, ja, ja! No te preocupes, nunca te dejaría atrás."

# game/script-grammar.rpy:370
translate spanish monika_gtod_tip008_07f907be:

    # m 3eub "Now, on the other hand, if I was the object of the sentence, I would need to use '{b}and me{/b}' instead."
    m 3eub "Ahora, por otro lado, si yo fuera el objeto de la frase, necesitaría usar '{b}y a mí{/b}' en su lugar."

# game/script-grammar.rpy:371
translate spanish monika_gtod_tip008_1df1bf5e:

    # m 3eua "For example:{w=0.5} '{b}Natsuki asked [player] and me if we liked her cupcakes.{/b}'"
    m 3eua "Por ejemplo:{w=0.5} '{b}Natsuki nos preguntó a [player] y a mí si nos gustaban sus cupcakes.{/b}'"

# game/script-grammar.rpy:372
translate spanish monika_gtod_tip008_d6d11850:

    # m 1eub "I hope that helps the next time you come across this situation while writing, [player]!"
    m 1eub "¡Espero que eso ayude la próxima vez que te encuentres con esta situación al escribir, [player]!"

# game/script-grammar.rpy:373
translate spanish monika_gtod_tip008_564ab8cf:

    # m 3hub "Anyway, that's all for today, thanks for listening!"
    m 3hub "En fin, eso es todo por hoy, ¡gracias por escuchar!"

# game/script-grammar.rpy:401
translate spanish monika_gtod_tip009_84efe7ba:

    # m 1eua "Today we're going to talk about apostrophes. Pretty straightforward, right?"
    m 1eua "Hoy vamos a hablar de los apóstrofos. Bastante sencillo, ¿verdad?"

# game/script-grammar.rpy:402
translate spanish monika_gtod_tip009_395010cd:

    # m 3eua "Add them to show possession: '{b}Sayori’s fork, Natsuki’s spoon, Yuri’s knife{/b}...'"
    m 3eua "En inglés, los añadimos para mostrar posesión: '{b}Sayori’s fork, Natsuki’s spoon, Yuri’s knife{/b}'..."

# game/script-grammar.rpy:403
translate spanish monika_gtod_tip009_6f9b19a4:

    # m 1esd "I guess the issue that can come up is when you have to add an apostrophe to a word that ends with an '{b}s{/b}.'"
    m 1esd "Supongo que la duda surge cuando tienes que añadir un apóstrofo a una palabra que termina en '{b}s{/b}'."

# game/script-grammar.rpy:404
translate spanish monika_gtod_tip009_0af44593:

    # m 3eub "For plural words, this is simple; just add the apostrophe at the end:{w=0.5} '{b}monkeys’{/b}.'"
    m 3eub "Para palabras en plural, es simple; solo añade el apóstrofo al final:{w=0.5} '{b}monkeys’{/b}'."

# game/script-grammar.rpy:405
translate spanish monika_gtod_tip009_37dc1efb:

    # m 1hksdla "It's pretty clear that '{b}monkey’s{/b},' which would indicate possession belonging to a single monkey, or '{b}monkeys’s{/b}' would be wrong."
    m 1hksdla "Está bastante claro que '{b}monkey’s{/b}', que indicaría posesión de un solo mono, o '{b}monkeys’s{/b}' estaría mal."

# game/script-grammar.rpy:406
translate spanish monika_gtod_tip009_1d0da10b:

    # m 1eud "The gray area that comes up is when we bring in people's names, like '{b}Sanders{/b}' or '{b}[tempname]{/b}.'"
    m 1eud "La ambigüedad surge cuando introducimos nombres de personas, como '{b}Sanders{/b}' o '{b}[tempname]{/b}'."

# game/script-grammar.rpy:407
translate spanish monika_gtod_tip009_85b62dca:

    # m 1euc "In some style guides I've read, it seems that we usually add an apostrophe and '{b}s{/b}' as usual, with the exception of historical names like '{b}Sophocles{/b}' or '{b}Zeus{/b}.'"
    m 1euc "En algunas guías de estilo que he leído, parece que solemos añadir un apóstrofo y una '{b}s{/b}' como de costumbre, con la excepción de nombres históricos como '{b}Sophocles{/b}' o '{b}Zeus{/b}'."

# game/script-grammar.rpy:408
translate spanish monika_gtod_tip009_418cae0d:

    # m 3eub "Personally, I think all that matters here is consistency!"
    m 3eub "Personalmente, ¡creo que lo único que importa aquí es la coherencia!"

# game/script-grammar.rpy:409
translate spanish monika_gtod_tip009_78120e5e:

    # m 3esd "If you're going to go with '{b}[tempname]’{/b},' then it's fine as long as you use '{b}[tempname]’{/b}' for the entire text."
    m 3esd "Si vas a optar por '{b}[tempname]’{/b}', entonces está bien siempre que uses '{b}[tempname]’{/b}' en todo el texto."

# game/script-grammar.rpy:410
translate spanish monika_gtod_tip009_4b444bee:

    # m 1tuu "That matters more than honoring some old Greeks to me."
    m 1tuu "Eso me importa más que honrar a unos antiguos griegos."

# game/script-grammar.rpy:411
translate spanish monika_gtod_tip009_484088d0:

    # m 3eud "One interesting exception is the case of '{b}its{/b}' versus '{b}it’s{/b}.'"
    m 3eud "Una excepción interesante es el caso de '{b}its{/b}' frente a '{b}it’s{/b}'."

# game/script-grammar.rpy:412
translate spanish monika_gtod_tip009_c35edfcf:

    # m 3etc "You would think that for the possessive form of '{b}it{/b}' you would add an apostrophe, making it '{b}it’s{/b},' right?"
    m 3etc "Pensarías que para la forma posesiva de '{b}it{/b}' añadirías un apóstrofo, haciéndolo '{b}it’s{/b}', ¿verdad?"

# game/script-grammar.rpy:413
translate spanish monika_gtod_tip009_2ac5875f:

    # m 3euc "Normally this would be correct, but in this case the possessive form of '{b}it{/b}' is simply '{b}its{/b}.'"
    m 3euc "Normalmente esto sería correcto, pero en este caso la forma posesiva de '{b}it{/b}' es simplemente '{b}its{/b}'."

# game/script-grammar.rpy:414
translate spanish monika_gtod_tip009_41c5aee5:

    # m 1esd "This is because '{b}it’s{/b}' is reserved for the contracted form of '{b}it is{/b}.'"
    m 1esd "Esto es porque '{b}it’s{/b}' está reservado para la forma contraída de '{b}it is{/b}'."

# game/script-grammar.rpy:415
translate spanish monika_gtod_tip009_a564d647:

    # m 1eua "If you're wondering, a contraction is simply a shortened version of a word or words, with an apostrophe indicating where letters have been left out to make the contraction."
    m 1eua "Si te lo preguntas, una contracción es simplemente una versión abreviada de una palabra o palabras, con un apóstrofo indicando dónde se han omitido letras para hacer la contracción."

# game/script-grammar.rpy:416
translate spanish monika_gtod_tip009_50e7b768:

    # m 1eub "Okay, [player], {i}it's{/i} about time to wrap it up...{w=0.5}I think this lesson has run {i}its{/i} course."
    m 1eub "Vale, [player], creo que ya va siendo hora de terminar... {w=0.5}Esta lección ha dado de sí todo lo que podía. ¡Si hablásemos en inglés, este sería el momento perfecto para usar 'it's' e 'its'!"

# game/script-grammar.rpy:417
translate spanish monika_gtod_tip009_5ffdf762:

    # m 3hub "Ehehe. Thanks for listening!"
    m 3hub "Je, je, je. ¡Gracias por escuchar!"

# game/script-grammar.rpy:439
translate spanish monika_gtod_tip010_cf2e6935:

    # m 3eud "Did you know there's actually a debate about the placement of a specific comma in a list of three items?"
    m 3eud "¿Sabías que hay un debate sobre la colocación de una coma específica en una lista de tres elementos?"

# game/script-grammar.rpy:440
translate spanish monika_gtod_tip010_890ed304:

    # m 3eub "This is called the Oxford, or serial, comma, and it's been known to completely change the meaning of a sentence!"
    m 3eub "Se la conoce como la coma de Oxford, o serial, ¡y tiene fama de cambiar por completo el significado de una frase!"

# game/script-grammar.rpy:441
translate spanish monika_gtod_tip010_2004644b:

    # m 1esa "Let me show you what I mean..."
    m 1esa "Déjame mostrarte a qué me refiero..."

# game/script-grammar.rpy:442
translate spanish monika_gtod_tip010_04f8d78a:

    # m 1hub "With the Oxford comma, I would say '{b}I love [player], reading, and writing.{/b}'"
    m 1hub "Con la coma de Oxford, diría: '{b}Amo a [player], leer, y escribir{/b}'."

# game/script-grammar.rpy:443
translate spanish monika_gtod_tip010_6c231df4:

    # m 1eua "Without the Oxford comma, I would say '{b}I love [player], reading and writing.{/b}'"
    m 1eua "Sin la coma de Oxford, diría: '{b}Amo a [player], leer y escribir{/b}'."

# game/script-grammar.rpy:444
translate spanish monika_gtod_tip010_6be40e6a:

    # m 3eud "The confusion lies in whether I'm referring to loving three separate things, or if I'm referring to just loving you when you read and write."
    m 3eud "La confusión reside en si me refiero a amar tres cosas separadas, o si me refiero a que simplemente te amo a ti cuando lees y escribes."

# game/script-grammar.rpy:445
translate spanish monika_gtod_tip010_af5fe8a0:

    # m 3hub "Of course, both of those meanings are true, so there's no confusion there for me, ahaha!"
    m 3hub "Por supuesto, ambos significados son ciertos, así que no hay confusión para mí, ¡ja, ja, ja!"

# game/script-grammar.rpy:446
translate spanish monika_gtod_tip010_e428a7a8:

    # m 1eua "That's all I have for today, [player]."
    m 1eua "Eso es todo lo que tengo por hoy, [player]."

# game/script-grammar.rpy:447
translate spanish monika_gtod_tip010_7566f426:

    # m 3hub "Thanks for listening!"
    m 3hub "¡Gracias por escuchar!"

translate spanish strings:

    # game/script-grammar.rpy:53
    old "Can you teach me about grammar?"
    new "¿Puedes enseñarme gramática?"

    # game/script-grammar.rpy:92
    old "Clauses"
    new "Cláusulas"

    # game/script-grammar.rpy:117
    old "Comma Splices and Run-ons"
    new "Empalmes por coma y oraciones fusionadas"

    # game/script-grammar.rpy:153
    old "Conjunctions"
    new "Conjunciones"

    # game/script-grammar.rpy:200
    old "Semicolons"
    new "Puntos y comas"

    # game/script-grammar.rpy:239
    old "Subjects and Objects"
    new "Sujetos y objetos"

    # game/script-grammar.rpy:274
    old "Active and Passive Voices"
    new "Voz activa y pasiva"

    # game/script-grammar.rpy:308
    old "Who vs. Whom"
    new "Who vs. Whom"

    # game/script-grammar.rpy:343
    old "And I vs. And me"
    new "And I vs. And me"

    # game/script-grammar.rpy:381
    old "Apostrophes"
    new "Apóstrofos"

    # game/script-grammar.rpy:425
    old "The Oxford Comma"
    new "La coma de Oxford"

    # game/script-grammar.rpy:49
    old "grammar tips"
    new "consejos de gramática"

