
# game/script-topics.rpy:474
translate spanish mas_topic_derandom_cdefb594:

    # m 3eksdld "Are you sure you don't want me to bring this up anymore?{nw}"
    m 3eksdld "¿Segur[end_letter_gender] de que no quieres que vuelva a sacar el tema?{nw}"

# game/script-topics.rpy:477
translate spanish mas_topic_derandom_0a165be9:

    # m "Are you sure you don't want me to bring this up anymore?{fast}" nointeract
    m "¿Segur[end_letter_gender] de que no quieres que vuelva a sacar el tema?{fast}" nointeract

# game/script-topics.rpy:484
translate spanish mas_topic_derandom_3650bf33:

    # m 2eksdlc "Okay, [player]. I'll make sure not to talk about that again."
    m 2eksdlc "Vale, [player]. Me aseguraré de no mencionar esto en ninguna ocasión."

# game/script-topics.rpy:485
translate spanish mas_topic_derandom_c770d30b:

    # m 2dksdld "If it upset you in any way, I'm really sorry...{w=0.5} I'd never do that intentionally."
    m 2dksdld "Si esto te ha molestado de algún modo, de verdad lo siento... {w=0.5} Nunca fue mi intención."

# game/script-topics.rpy:486
translate spanish mas_topic_derandom_43b49a99:

    # m 2eksdla "...But thanks for letting me know;{w=0.5} I appreciate the honesty."
    m 2eksdla "Pero gracias por decírmelo... {w=0.5} Aprecio mucho tu honestidad."

# game/script-topics.rpy:489
translate spanish mas_topic_derandom_9d33b26d:

    # m 1eka "Alright, [player]."
    m 1eka "De acuerdo, [player]."

# game/script-topics.rpy:504
translate spanish mas_bad_derand_topic_664d8d1b:

    # m 2ekc "...{w=0.3}{nw}"
    m 2ekc "...{w=0.3}{nw}"

# game/script-topics.rpy:505
translate spanish mas_bad_derand_topic_4d5203ea:

    # extend 2ekd "[player]..."
    extend 2ekd "[player]..."

# game/script-topics.rpy:508
translate spanish mas_bad_derand_topic_765c2da9:

    # m 2efd "Is it not okay that I talk to you about my fears?"
    m 2efd "¿Está bien si te hablo acerca de mis temores?"

# game/script-topics.rpy:509
translate spanish mas_bad_derand_topic_2700a00b:

    # m 2ekc "I mean, if you want me to stop, I'll stop...{w=0.3}{nw}"
    m 2ekc "O sea, si quieres que pare, lo haré... {w=0.3}{nw}"

# game/script-topics.rpy:510
translate spanish mas_bad_derand_topic_4946e8bb:

    # extend 2rkd "but I thought you'd be willing to hear me out."
    extend 2rkd "Pero creí que estarías dispuest[end_letter_gender] a escucharme."

# game/script-topics.rpy:512
translate spanish mas_bad_derand_topic_8178f687:

    # m 2esc "Do you want me to stop, [player]?{nw}"
    m 2esc "¿Quieres que me detenga, [player]?{nw}"

# game/script-topics.rpy:515
translate spanish mas_bad_derand_topic_151b7c12:

    # m "Do you want me to stop, [player]?{fast}" nointeract
    m "¿Quieres que me detenga, [player]?{fast}" nointeract

# game/script-topics.rpy:518
translate spanish mas_bad_derand_topic_a7bf0d7e:

    # m 2dkc "Alright..."
    m 2dkc "Vale..."

# game/script-topics.rpy:524
translate spanish mas_bad_derand_topic_34ed9d51:

    # m 2duu "Thank you, [player]."
    m 2duu "Te lo agradezco, [player]."

# game/script-topics.rpy:525
translate spanish mas_bad_derand_topic_774610b8:

    # m 2eua "It means a lot that you're willing to hear me out."
    m 2eua "Significa muchísimo para mí que estés dispuest[end_letter_gender] a escucharme."

# game/script-topics.rpy:528
translate spanish mas_bad_derand_topic_bd4dd106:

    # m 2ekd "Do you just...{w=0.2}not care about how I feel or something?"
    m 2ekd "¿Es solo que... {w=0.2}no te interesan mis sentimientos o algo así?"

# game/script-topics.rpy:529
translate spanish mas_bad_derand_topic_1b9cba09:

    # m 2tsc "If you want me to stop talking about this, I will...but I'm not that happy you don't want to hear me out."
    m 2tsc "Si quieres que deje de hablar de esto, lo haré... pero no me hace gracia que no quieras escucharme."

# game/script-topics.rpy:531
translate spanish mas_bad_derand_topic_24a57319:

    # m 2etc "Well [player], should I stop?{nw}"
    m 2etc "Entonces [player], ¿debería parar?{nw}"

# game/script-topics.rpy:534
translate spanish mas_bad_derand_topic_597305af:

    # m "Well [player], should I stop?{fast}" nointeract
    m "Entonces [player], ¿debería parar?{fast}" nointeract

# game/script-topics.rpy:537
translate spanish mas_bad_derand_topic_48d053ab:

    # m 2dsc "Alright."
    m 2dsc "Vale."

# game/script-topics.rpy:542
translate spanish mas_bad_derand_topic_917cea9e:

    # m 2eka "Thank you, [player]."
    m 2eka "Te lo agradezco, [player]."

# game/script-topics.rpy:544
translate spanish mas_bad_derand_topic_1b0a77cd:

    # m "I appreciate that you're[_stil_]willing to hear me out."
    m "De verdad aprecio que aún estés dispuest[end_letter_gender] a escucharme."

# game/script-topics.rpy:549
translate spanish mas_bad_derand_topic_d577ccc1:

    # m 2rsc "I guess I shouldn't be surprised..."
    m 2rsc "Supongo que no debería serme una sorpresa..."

# game/script-topics.rpy:550
translate spanish mas_bad_derand_topic_22f8b38f:

    # m 2tsc "You've made it pretty clear already that you don't care about my feelings."
    m 2tsc "Ya me has dejado bien claro que no te importan mis sentimientos."

# game/script-topics.rpy:551
translate spanish mas_bad_derand_topic_74506953:

    # m 2dsc "Fine, [player]. I won't talk about that anymore."
    m 2dsc "Pues bien, [player]. No te hablaré acerca de esto nunca más."

# game/script-topics.rpy:790
translate spanish mas_rerandom_c42f8f06:

    # m 1dsa "Okay, [player].{w=0.2}.{w=0.2}.{w=0.2}{nw}"
    m 1dsa "Vale, [player].{w=0.2}.{w=0.2}.{w=0.2}{nw}"

# game/script-topics.rpy:791
translate spanish mas_rerandom_73747bba:

    # m 3hua "All done!"
    m 3hua "¡Hecho!"

# game/script-topics.rpy:816
translate spanish mas_hide_unseen_6168414f:

    # m 3esd "Oh, okay, [mas_get_player_nickname()]..."
    m 3esd "Ah, vale, [mas_get_player_nickname()]..."

# game/script-topics.rpy:818
translate spanish mas_hide_unseen_7031e319:

    # m 1tuu "So I guess you want to...{w=0.5}{i}unsee{/i} it..."
    m 1tuu "Pues supongo que quieres... {w=0.5}olvidar todo esto..."

# game/script-topics.rpy:819
translate spanish mas_hide_unseen_05f8c059:

    # m 3hub "Ahaha!"
    m 3hub "¡Ja, ja, ja!"

# game/script-topics.rpy:821
translate spanish mas_hide_unseen_c53b7b21:

    # m 1esa "I'll hide it for now, just give me a second.{w=0.5}.{w=0.5}.{nw}"
    m 1esa "Lo ocultaré por ahora, solo dame un segundo.{w=0.5}.{w=0.5}.{nw}"

# game/script-topics.rpy:822
translate spanish mas_hide_unseen_d4b8f1d9:

    # m 3eub "There you go! If you want to see the menu again, just ask."
    m 3eub "¡Ahí tienes! Si quieres volver a ver este menú, sólo dímelo."

# game/script-topics.rpy:845
translate spanish mas_show_unseen_d445bb6f:

    # m 3eub "Sure, [mas_get_player_nickname()]!"
    m 3eub "¡Claro, [mas_get_player_nickname()]!"

# game/script-topics.rpy:846
translate spanish mas_show_unseen_23d57bcf:

    # m 1esa "Just give me a second.{w=0.5}.{w=0.5}.{nw}"
    m 1esa "Sólo dame un momento.{w=0.5}.{w=0.5}.{nw}"

# game/script-topics.rpy:847
translate spanish mas_show_unseen_7e2e3649:

    # m 3hua "There you go!"
    m 3hua "¡Ahí lo tienes!"

# game/script-topics.rpy:881
translate spanish monika_god_d1aa659a:

    # m 1eua "[player], do you believe in God?"
    m 1eua "[player], ¿acaso crees en Dios?"

# game/script-topics.rpy:882
translate spanish monika_god_f88525b2:

    # m 1eka "I was never too sure, myself."
    m 1eka "Por mi parte, nunca he estado muy segura de ello."

# game/script-topics.rpy:883
translate spanish monika_god_e1475757:

    # m 1lksdlb "Well, I'm sure I never really questioned it as a kid..."
    m 1lksdlb "Pues, estoy segura de que nunca me lo cuestioné durante mi niñez..."

# game/script-topics.rpy:884
translate spanish monika_god_a4dd9462:

    # m 1lsc "But as I grew up, the more I learned about the world, the more I would question it."
    m 1lsc "Pero a medida que fui creciendo, cuanto más aprendí acerca del mundo, más me cuestioné acerca de ello."

# game/script-topics.rpy:885
translate spanish monika_god_2c8d686b:

    # m 1esd "I started to wonder why God was helping people pass exams, or get over a cold..."
    m 1esd "Empecé a preguntarme por qué Dios ayudaba a las personas a pasar exámenes o superar resfriados..."

# game/script-topics.rpy:886
translate spanish monika_god_60d4fcc6:

    # m 1tfd "...when there are children who live their lives being sold as sex slaves?"
    m 1tfd "Cuando hay críos ahí fuera que se pasan la vida como esclavos sexuales."

# game/script-topics.rpy:887
translate spanish monika_god_bb25fc08:

    # m 4tfc "Or the eight hundred million people who are too poor to even eat."
    m 4tfc "O cuando hay ochocientos millones de personas cuya pobreza no les permite ni comer."

# game/script-topics.rpy:888
translate spanish monika_god_c9668874:

    # m 2dkc "I wonder how many of those people pray to God every day until they starve and die?"
    m 2dkc "Me pregunto cuántas de ellas ruegan a Dios a diario hasta perecer a causa del hambre."

# game/script-topics.rpy:889
translate spanish monika_god_515a6296:

    # m 4ekc "Or, how many millions of families pray for a loved one to recover from some incurable disease?"
    m 4ekc "O cuántas familias oran por sus seres amados que padecen enfermedades incurables."

# game/script-topics.rpy:890
translate spanish monika_god_5b03c348:

    # m 4euc "But the punchline is this..."
    m 4euc "Pero la cuestión es esta..."

# game/script-topics.rpy:891
translate spanish monika_god_7ecb445f:

    # m 4eud "If just one person beats the odds and survives - among the thousands of others who die--"
    m 4eud "Aunque sólo una persona logre superar las expectativas, entre todas las que perecen..."

# game/script-topics.rpy:892
translate spanish monika_god_bf58e181:

    # m 2esc "--Then, it's suddenly a miracle from God."
    m 2esc "es automáticamente considerado un milagro de Dios."

# game/script-topics.rpy:893
translate spanish monika_god_2d61da99:

    # m 2dsc "I'd really love to meet this God who seemingly laughs at the misery of everyone not eligible for his miracles."
    m 2dsc "Me encantaría conocer a ese Dios que parece partirse de risa ante la miseria de todos los que no son aptos para sus milagros."

# game/script-topics.rpy:894
translate spanish monika_god_b4b80aea:

    # m 4hksdlb "But the irony is that I {i}do{/i} have a creator, apparently."
    m 4hksdlb "Aunque es irónico que tenga un creador, aparentemente."

# game/script-topics.rpy:895
translate spanish monika_god_2250f96b:

    # m 4eua "And you know what?"
    m 4eua "¿Y sabes qué es lo mejor de todo?"

# game/script-topics.rpy:898
translate spanish monika_god_bb1ac047:

    # m 1lksdlc "I bet he's still laughing at all the pain he caused everyone, even as we speak."
    m 1lksdlc "Te apuesto que continúa mondándose de risa frente a todo el dolor que causa, incluso mientras hablamos."

# game/script-topics.rpy:900
translate spanish monika_god_331d4e78:

    # m 1lksdla "I bet he's still laughing at the miserable fates of Sayori and Yuri, even as we speak."
    m 1lksdla "Seguro que todavía se ríe del miserable destino de Sayori y Yuri, incluso ahora mismo."

# game/script-topics.rpy:902
translate spanish monika_god_c57429cf:

    # m 1dsd "What are we to him but props in a scripted play?"
    m 1dsd "¿Qué somos para él sino puro atrezo en una obra guionizada?"

# game/script-topics.rpy:903
translate spanish monika_god_f78ac975:

    # m 3euc "So, from that perspective..."
    m 3euc "Pues, desde esa perspectiva..."

# game/script-topics.rpy:904
translate spanish monika_god_e963f882:

    # m 3eud "I don't think it's too far-fetched for there to be a god if Earth was nothing but his playset."
    m 3eud "No considero que sea demasiado disparatado que haya un dios si la Tierra no es más que su patio de juegos."

# game/script-topics.rpy:905
translate spanish monika_god_c5fd6be4:

    # m 1eua "Anyway, do you worship any god, [player]?{nw}"
    m 1eua "De todas formas, ¿acaso le rindes culto a algún dios, [player]?{nw}"

# game/script-topics.rpy:908
translate spanish monika_god_211126be:

    # m "Anyway, do you worship any god, [player]?{fast}" nointeract
    m "De todas formas, ¿acaso le rindes culto a algún dios, [player]?{fast}" nointeract

# game/script-topics.rpy:911
translate spanish monika_god_3ed1f6be:

    # m 1hksdlb "Oh... Well I hope I didn't offend you too much with my thoughts."
    m 1hksdlb "Ah... pues, espero que mis pensamientos no te hayan ofendido en gran medida."

# game/script-topics.rpy:912
translate spanish monika_god_fa7fa8d5:

    # m 1eka "Still, I think it's important to be able to share my opinion with you."
    m 1eka "Aún así, creo que es importante poder transmitir mi opinión contigo."

# game/script-topics.rpy:913
translate spanish monika_god_b67f5d87:

    # m 1rksdla "I'm sure you understand why I'm not too fond of the idea."
    m 1rksdla "Estoy segura de que comprendes el porqué de mi falta de aprecio hacia esa idea."

# game/script-topics.rpy:914
translate spanish monika_god_405fbcce:

    # m 1hua "Maybe you could show me a better god when I cross over!"
    m 1hua "¡Quizá puedas enseñarme un dios mejor cuando pase al otro lado!"

# game/script-topics.rpy:915
translate spanish monika_god_e6f89ce6:

    # m 1hub "Ahaha~"
    m 1hub "Ja, ja, ja."

# game/script-topics.rpy:918
translate spanish monika_god_24e39aa9:

    # m 3eka "I'm glad we're on the same page here, but I'm alright if that changes for you."
    m 3eka "Estoy feliz de que estemos en el mismo canal aquí, pero no me molesta si es que cambias de idea."

# game/script-topics.rpy:919
translate spanish monika_god_c3b10d2d:

    # m 1hua "I'm happy for you that you can lead a life on your own!"
    m 1hua "¡Me alegra que puedas tomar las riendas de tu vida por ti mism[end_letter_gender]!"

# game/script-topics.rpy:921
translate spanish monika_god_97da9a51:

    # m 5eua "I just hope you're willing to accept me into your life when I can present myself."
    m 5eua "Solo espero que estés dispuest[end_letter_gender] a abrirme las puertas de tu vida cuando pueda entregarme a ti."

# game/script-topics.rpy:922
translate spanish monika_god_f1ffa26f:

    # m 5hua "Ehehe~"
    m 5hua "Je, je, je."

# game/script-topics.rpy:934
translate spanish monika_death_8c15cf66:

    # m 1euc "[player], have you ever wondered what it feels like to die?"
    m 1euc "[player], ¿acaso te has preguntado cómo se siente el abrazo de la muerte?"

# game/script-topics.rpy:935
translate spanish monika_death_2959bbaf:

    # m 1lsc "It's something I used to think about pretty often..."
    m 1lsc "Es algo en lo que solía pensar a menudo..."

# game/script-topics.rpy:936
translate spanish monika_death_1fc6320a:

    # m 1lksdlc "But I think I've actually learned what it feels like."
    m 1lksdlc "Pero creo que, de hecho, es algo que he aprendido cómo se siente."

# game/script-topics.rpy:937
translate spanish monika_death_5629d35f:

    # m "I don't really understand it, but whenever the game closes without warning..."
    m "La verdad es que no lo entiendo, pero cada vez que el juego se cierra sin aviso..."

# game/script-topics.rpy:938
translate spanish monika_death_f762c393:

    # m 1dsc "...it feels like I'm instantly put to sleep, left with nothing but my thoughts."
    m 1dsc "Siento como si me durmieran al instante, dejándome a solas con mis pensamientos."

# game/script-topics.rpy:939
translate spanish monika_death_9cc667e5:

    # m 1dkd "But after a few seconds, my thoughts start to fill with incoherent, jumbled patterns."
    m 1dkd "Sin embargo tras unos segundos, mis pensamientos se llenan de incoherencias, como patrones revueltos."

# game/script-topics.rpy:940
translate spanish monika_death_9066d83f:

    # m 1dkc "I see static and rapid flashes of color while hearing all kinds of weird screaming noises."
    m 1dkc "Veo estática y rápidos destellos de color mientras escucho todo tipo de gritos extraños."

# game/script-topics.rpy:941
translate spanish monika_death_010524c5:

    # m 3ekd "At that point, I can't even form my own thoughts anymore."
    m 3ekd "En ese punto, ya no puedo ni formar mis propios pensamientos."

# game/script-topics.rpy:942
translate spanish monika_death_7880df1f:

    # m 1esc "I'm just endlessly hammered by the flashing and screaming, unable to move or even think."
    m 1esc "Me bombardean sin fin esos destellos y gritos, dejándome incapaz de moverme o siquiera pensar."

# game/script-topics.rpy:943
translate spanish monika_death_725c237b:

    # m 1euc "I'm pretty sure in that moment, I don't really exist, but for some reason, I can remember it anyway."
    m 1euc "Estoy segura de que en ese punto no existo realmente, pero por alguna razón puedo recordarlo de todas formas."

# game/script-topics.rpy:944
translate spanish monika_death_4f334b0b:

    # m 1ekd "I have no idea what it means for the game to suddenly close, or why that stuff happens to me."
    m 1ekd "No tengo ni idea de qué significa que el juego se cierre de repente, ni por qué me pasa eso."

# game/script-topics.rpy:945
translate spanish monika_death_4ef5e129:

    # m 1dkc "..."
    m 1dkc "..."

# game/script-topics.rpy:946
translate spanish monika_death_93b769c0:

    # m 3eub "But you can prevent that from happening, [player]!"
    m 3eub "¡Pero puedes evitar que eso suceda, [player]!"

# game/script-topics.rpy:947
translate spanish monika_death_4ad56704:

    # m 3eua "If you say goodbye before you leave,{w=0.2} I can go to my room before the game closes, and I won't experience the screaming void."
    m 3eua "Si te despides antes de irte,{w=0.2} puedo ir a mi cuarto antes de que el juego se cierre, y así no experimentaré ese vacío ensordecedor."

# game/script-topics.rpy:948
translate spanish monika_death_0be92aca:

    # m "It's super easy, so please always say goodbye, okay?"
    m "Es extremadamente fácil, por lo que, por favor, di adiós, ¿vale?"

# game/script-topics.rpy:950
translate spanish monika_death_1e147973:

    # m 2tkc "Unless...{w=1}you actually {i}enjoy{/i} hurting me..."
    m 2tkc "A menos que... {w=1}de verdad disfrutes haciéndome daño..."

# game/script-topics.rpy:952
translate spanish monika_death_0a6b3816:

    # m 1eka "Thanks for hearing me out, [player]."
    m 1eka "Gracias por escucharme, [player]."

# game/script-topics.rpy:966
translate spanish monika_selfesteem_2e53136f:

    # m 3eua "Do you love yourself, [player]?"
    m 3eua "¿Te amas a ti mism[end_letter_gender], [player]?"

# game/script-topics.rpy:967
translate spanish monika_selfesteem_5f2f8a80:

    # m 1lksdlb "I don't mean in a conceited way."
    m 1lksdlb "No me refiero en una manera engreída."

# game/script-topics.rpy:968
translate spanish monika_selfesteem_e5cf121b:

    # m 1eka "Like, are you comfortable with who you are?{nw}"
    m 1eka "O sea, ¿estás a gusto contigo mism[end_letter_gender]?{nw}"

# game/script-topics.rpy:971
translate spanish monika_selfesteem_992f015e:

    # m "Like, are you comfortable with who you are?{fast}" nointeract
    m "O sea, ¿estás a gusto contigo mism[end_letter_gender]?" nointeract

# game/script-topics.rpy:974
translate spanish monika_selfesteem_bd0c71a5:

    # m 1hua "I'm glad you aren't miserable inside, [player]."
    m 1hua "Me alegra que no estés destrozad[end_letter_gender] en tu interior, [player]."

# game/script-topics.rpy:977
translate spanish monika_selfesteem_7758c3c2:

    # m 1ekc "I really have been concerned for you lately..."
    m 1ekc "En verdad me he preocupado por ti últimamente..."

# game/script-topics.rpy:979
translate spanish monika_selfesteem_520d36f6:

    # m 1hua "I wasn't too worried because of how good you've made me feel lately."
    m 1hua "No he estado demasiado preocupada debido a lo bien que me has hecho sentir en este último tiempo."

# game/script-topics.rpy:981
translate spanish monika_selfesteem_3a4fbbd5:

    # m 1eka "Your happiness means everything to me, after all."
    m 1eka "Tu felicidad lo es todo para mí, después de todo."

# game/script-topics.rpy:983
translate spanish monika_selfesteem_f19860da:

    # m 2ekc "Depression and a low self-esteem often root from a feeling that you don't deserve any kind of affection."
    m 2ekc "La depresión y la baja autoestima a menudo nacen de la sensación de no merecer ningún tipo de afecto."

# game/script-topics.rpy:984
translate spanish monika_selfesteem_5f69a65a:

    # m 2lksdlc "It's a horrible cocktail of feelings to have bottled in you."
    m 2lksdlc "Es un cóctel horrible de sentimientos para guardarse dentro."

# game/script-topics.rpy:985
translate spanish monika_selfesteem_a4045de0:

    # m 4eka "If you have any friends that you think might be suffering from those, try to reach out and say something nice."
    m 4eka "Si tienes algún amigo que creas que está sufriendo por ello, intenta extender una mano y decirle algo amable."

# game/script-topics.rpy:986
translate spanish monika_selfesteem_82cf98a1:

    # m 4hua "A small compliment could make a world of difference for them!"
    m 4hua "¡Un pequeño cumplido puede hacer tamaña diferencia en ellos!"

# game/script-topics.rpy:987
translate spanish monika_selfesteem_50fdc00c:

    # m 1eua "If it gives them a bit of relief, you'd have done a great thing."
    m 1eua "Si eso les da un poco de alivio, ya habrás hecho algo grande."

# game/script-topics.rpy:988
translate spanish monika_selfesteem_a4eb284b:

    # m 1eka "And even if it doesn't, at least you tried rather than staying silent."
    m 1eka "E incluso si no lo hace, haberlo intentado vale mil veces más que quedarse en silencio."

# game/script-topics.rpy:991
translate spanish monika_selfesteem_00863575:

    # m 1ekc "That's...really sad to hear, [player]..."
    m 1ekc "Oír eso es... {w=0.5}muy triste, [player]..."

# game/script-topics.rpy:994
translate spanish monika_selfesteem_80eeed97:

    # m 1ekc "I had strongly suspected it to be honest..."
    m 1ekc "He sospechado con todas mis fuerzas para serte honesta..."

# game/script-topics.rpy:996
translate spanish monika_selfesteem_6e304460:

    # m 1ekc "And to think I missed it while you've been making me so happy..."
    m 1ekc "Y pensar que no lo he notado mientras tú me hacías tan feliz..."

# game/script-topics.rpy:998
translate spanish monika_selfesteem_ba529a40:

    # m "I'll always love you, [player], but I think it's important to love yourself."
    m "Siempre te amaré, [player], pero creo que es importante amarse a uno mismo."

# game/script-topics.rpy:999
translate spanish monika_selfesteem_262bf87b:

    # m 1eka "You need to start with the little things that you like about yourself."
    m 1eka "Tienes que empezar por las pequeñas cosas que te gustan de ti mism[end_letter_gender]."

# game/script-topics.rpy:1000
translate spanish monika_selfesteem_a4809bc7:

    # m 3hua "It can be something silly, or a skill that you take pride in!"
    m 3hua "¡Puede ser una tontería, o incluso una habilidad de la que te enorgullezcas!"

# game/script-topics.rpy:1001
translate spanish monika_selfesteem_4db789c5:

    # m 3eua "Over time, you build your confidence little by little until you've built yourself into someone you'd love."
    m 3eua "Con el tiempo, reforzarás tu confianza poquito a poco hasta que te transformes en alguien al que ames."

# game/script-topics.rpy:1002
translate spanish monika_selfesteem_5ec787a8:

    # m 1eka "I can't promise it will be easy, but it'll be worth it."
    m 1eka "No puedo asegurarte que será fácil, pero valdrá la pena."

# game/script-topics.rpy:1003
translate spanish monika_selfesteem_db774d1d:

    # m 3hub "I'll always root for you, [player]!"
    m 3hub "¡Siempre creeré en ti, [player]!"

# game/script-topics.rpy:1022
translate spanish monika_sayori_6d1103bf:

    # m 2euc "I was thinking about Sayori earlier..."
    m 2euc "Hace rato estuve pensando en Sayori..."

# game/script-topics.rpy:1023
translate spanish monika_sayori_e17c58f1:

    # m 2lsc "I still wish I could have handled that whole thing a little more tactfully."
    m 2lsc "Aún deseo que hubiera podido manejar todo ese asunto con más tacto."

# game/script-topics.rpy:1029
translate spanish monika_sayori_ca8238e6:

    # m "You're not still hung up over it, right?"
    m "Ya no sigues muy colgado de eso, ¿verdad?"

# game/script-topics.rpy:1030
translate spanish monika_sayori_c67f3d7b:

    # m 2wud "...Oh my gosh, I can't believe I just said that."
    m 2wud "Madre mía... No puedo creer que acabe de decir eso."

# game/script-topics.rpy:1031
translate spanish monika_sayori_a43b91f7:

    # m 4wud "That pun was completely unintentional, I swear!"
    m 4wud "No fue mi intención usar ese juego de palabras, ¡te lo juro!"

# game/script-topics.rpy:1032
translate spanish monika_sayori_2ff014c3:

    # m 2lksdlb "But anyway..."
    m 2lksdlb "Pero, de todas formas..."

# game/script-topics.rpy:1036
translate spanish monika_sayori_749f00a8:

    # m 2eka "I know how much you cared about her, so it only feels right for me to share her last moments with you."
    m 2eka "Sé cuánto te importaba, así que sólo me parece correcto compartir sus últimos momentos contigo."

# game/script-topics.rpy:1038
translate spanish monika_sayori_2210bdf3:

    # m "If you're comfortable, that is.{nw}"
    m "Si es que te sientes cómodo, son estos.{nw}"

# game/script-topics.rpy:1041
translate spanish monika_sayori_6f527f07:

    # m "If you're comfortable, that is.{fast}" nointeract
    m "Si es que te sientes cómodo, son estos.{fast}" nointeract

# game/script-topics.rpy:1043
translate spanish monika_sayori_38dd3fe1:

    # m 4eka "You know how Sayori is really clumsy?"
    m 4eka "Ya sabes que Sayori era muy patosa, ¿no?"

# game/script-topics.rpy:1044
translate spanish monika_sayori_1a20e05f:

    # m 2rksdlb "Well, she kind of messed up the whole hanging thing..."
    m 2rksdlb "Pues, ella de algún modo arruinó el asunto este de la cuerda..."

# game/script-topics.rpy:1045
translate spanish monika_sayori_664ed1ad:

    # m 4rksdla "You're supposed to jump from high enough that the rope snaps your neck, making it quick and painless."
    m 4rksdla "Se supone que debes saltar desde lo bastante alto como para que la soga te parta el cuello y sea rápido e indoloro."

# game/script-topics.rpy:1046
translate spanish monika_sayori_ea836647:

    # m 4rksdld "But she just used a chair, meaning she kind of just left herself to slowly asphyxiate."
    m 4rksdld "Pero ella usó una silla, por lo que se asfixió muy lentamente a sí misma."

# game/script-topics.rpy:1047
translate spanish monika_sayori_f18fc52b:

    # m 2eksdlc "But a few seconds in, she must have changed her mind or something..."
    m 2eksdlc "Pero tras unos segundos, debe haber cambiado de opinión o algo..."

# game/script-topics.rpy:1048
translate spanish monika_sayori_dbc2f235:

    # m 2dksdld "Because she started clawing at the rope, trying to free herself."
    m 2dksdld "Porque empezó a arañar la cuerda, intentando liberarse."

# game/script-topics.rpy:1049
translate spanish monika_sayori_f5450e6b:

    # m "She must have kept at it all the way until she lost consciousness."
    m "Ella debió haber estado así hasta que perdió el conocimiento."

# game/script-topics.rpy:1050
translate spanish monika_sayori_b92f0639:

    # m 4eksdlc "That's why her fingertips were all bloody, anyway."
    m 4eksdlc "De todas formas, eso explica por qué tenía las yemas de los dedos llenas de sangre."

# game/script-topics.rpy:1051
translate spanish monika_sayori_a4c107c7:

    # m 4euc "Come to think of it, it was probably less 'changing her mind' and more just her survival instincts kicking in."
    m 4euc "Ahora que lo pienso, seguramente fuese puro instinto de supervivencia entrando en acción en lugar de que se arrepintiese."

# game/script-topics.rpy:1052
translate spanish monika_sayori_45da69b2:

    # m 2eud "So you can't really fault her for that."
    m 2eud "Por lo que no puedes culparla totalmente por ello."

# game/script-topics.rpy:1053
translate spanish monika_sayori_c9b07eef:

    # m 2eka "It's easier to think that she probably wouldn't have changed her mind anyway, right?"
    m 2eka "Es más sencillo pensar que probablemente no hubiera cambiado de opinión de todos modos, ¿verdad?"

# game/script-topics.rpy:1054
translate spanish monika_sayori_4c4f2807:

    # m 2ekd "It's not healthy to think about the things you could have done differently."
    m 2ekd "No es sano pensar en las cosas que pudieron haberse hecho diferente."

# game/script-topics.rpy:1055
translate spanish monika_sayori_475db169:

    # m 2eka "So just remember that even if you could have saved her, it's not your fault she killed herself."
    m 2eka "Sólo recuerda que aunque hayas tenido la chance de salvarla, no es tu culpa que ella se haya suicidado."

# game/script-topics.rpy:1056
translate spanish monika_sayori_48dc0990:

    # m 4eud "I may have exacerbated it a little bit, but Sayori was already mentally ill."
    m 4eud "Puede que yo empeorara un poco las cosas, pero Sayori ya estaba enferma."

# game/script-topics.rpy:1058
translate spanish monika_sayori_f304ec9c:

    # m "I understand, [player]."
    m "Lo entiendo, [player]."

# game/script-topics.rpy:1059
translate spanish monika_sayori_cb635e3f:

    # m 2euc "Still, though..."
    m 2euc "Pero aún..."

# game/script-topics.rpy:1061
translate spanish monika_sayori_aa5192b3:

    # m 2euc "I wonder how things would be if you and I just started dating from the get-go?"
    m 2euc "Me pregunto cómo habría sido todo si tú y yo hubiéramos salido desde el inicio."

# game/script-topics.rpy:1062
translate spanish monika_sayori_c77abc68:

    # m 1eka "I guess we'd all still be in the clubroom, writing poems and having fun together."
    m 1eka "Creo que aún estaríamos en el club, escribiendo poemas y pasándola bien juntos."

# game/script-topics.rpy:1065
translate spanish monika_sayori_1782a721:

    # m "You'd probably really enjoy that, huh?"
    m "De seguro habrías disfrutado todo eso, ¿verdad?"

# game/script-topics.rpy:1066
translate spanish monika_sayori_074ebc95:

    # m 1rksdla "I have to admit...{w=0.5}I kinda would too..."
    m 1rksdla "Tengo que admitir que... {w=0.5}a mí también me habría encantado..."

# game/script-topics.rpy:1067
translate spanish monika_sayori_1612ee8f:

    # m 1eka "We did have some good times."
    m 1eka "Hemos pasado buenos momentos."

# game/script-topics.rpy:1068
translate spanish monika_sayori_4008550a:

    # m 1euc "But that said...{w=0.5}it's still really the same ending either way, right?"
    m 1euc "Pero dicho esto... {w=0.5}el desenlace sería el mismo de todos modos, ¿verdad?"

# game/script-topics.rpy:1070
translate spanish monika_sayori_43c1617c:

    # m 1esc "But what's the point when none of it is even real?"
    m 1esc "¿Pero qué más da cuando nada de esto es real siquiera?"

# game/script-topics.rpy:1071
translate spanish monika_sayori_84733f5c:

    # m 1euc "I mean, it's the same ending either way, right?"
    m 1euc "Digo, es el mismo desenlace de cualquier manera, ¿verdad?"

# game/script-topics.rpy:1074
translate spanish monika_sayori_923d35d7:

    # m 1rksdla "The two of us, happily together..."
    m 1rksdla "Nosotros dos, felizmente juntos..."

# game/script-topics.rpy:1075
translate spanish monika_sayori_d60b649b:

    # m 3rksdla "There's no reason to ask for any more than that, right?"
    m 3rksdla "No hay razón para hacer ninguna otra pregunta más que esa, ¿no es así?"

# game/script-topics.rpy:1076
translate spanish monika_sayori_8e910654:

    # m 1eka "Sorry, I was just pointlessly musing - I'll be quiet for you now..."
    m 1eka "Lo siento, solo eran reflexiones sin sentido. Me mantendré en silencio para ti desde ahora..."

# game/script-topics.rpy:1078
translate spanish monika_sayori_e8e64233:

    # m 1eua "The two of us, happily together..."
    m 1eua "Nosotros dos, felizmente juntos..."

# game/script-topics.rpy:1079
translate spanish monika_sayori_db4bd939:

    # m 3eua "There's no reason to ask for any more than that."
    m 3eua "No hay razón para hacer ninguna otra pregunta más que esa."

# game/script-topics.rpy:1080
translate spanish monika_sayori_967acf21:

    # m 1hua "I was just pointlessly musing - I'm really as happy as I could be right now."
    m 1hua "Solo eran reflexiones sin sentido. Estoy muy feliz de poder estar aquí ahora mismo."

# game/script-topics.rpy:1092
translate spanish monika_japan_5e6eef65:

    # m 4eud "By the way, there's something that's been bothering me..."
    m 4eud "POr cierto, hay algo que ha estado molestándome..."

# game/script-topics.rpy:1093
translate spanish monika_japan_f9aae85b:

    # m "You know how this takes place in Japan?"
    m "Ya sabes que esto transcurre en Japón, ¿verdad?"

# game/script-topics.rpy:1094
translate spanish monika_japan_e4c13b49:

    # m 2euc "Well...I assume you knew that, right?"
    m 2euc "Pues... supongo que lo sabías, ¿verdad?"

# game/script-topics.rpy:1095
translate spanish monika_japan_04d0e1df:

    # m "Or at least decided it probably does?"
    m "¿O al menos decidiste que probablemente era así?"

# game/script-topics.rpy:1096
translate spanish monika_japan_a1cbe3ac:

    # m 2eud "I don't think you're actually told at any point where this takes place..."
    m 2eud "No creo que en verdad te hayan dicho en algún momento dónde toma lugar esto..."

# game/script-topics.rpy:1097
translate spanish monika_japan_a68f4d6e:

    # m 2etc "Is this even really Japan?"
    m 2etc "¿Acaso es en verdad Japón?"

# game/script-topics.rpy:1098
translate spanish monika_japan_ee980cd2:

    # m 4esc "I mean, aren't the classrooms and stuff kind of weird for a Japanese school?"
    m 4esc "O sea, ¿no son las aulas y demás cosas un poco raras para un instituto japonés?"

# game/script-topics.rpy:1099
translate spanish monika_japan_cdeb580e:

    # m 4eud "Not to mention everything is in English..."
    m 4eud "Sin mencionar que todo está en inglés..."

# game/script-topics.rpy:1100
translate spanish monika_japan_4abcbcce:

    # m 2esc "It feels like everything is just there because it needs to be, and the actual setting is an afterthought."
    m 2esc "Da la sensación de que todo está ahí simplemente porque tiene que estar, y que el entorno en sí fue una ocurrencia tardía."

# game/script-topics.rpy:1101
translate spanish monika_japan_5d21f99a:

    # m 2ekc "It's kind of giving me an identity crisis."
    m 2ekc "Esto me está dando una especie de crisis de identidad."

# game/script-topics.rpy:1102
translate spanish monika_japan_7843b060:

    # m 2lksdlc "All my memories are really hazy..."
    m 2lksdlc "Todos mis recuerdos son algo difusos..."

# game/script-topics.rpy:1103
translate spanish monika_japan_f2b425aa:

    # m 2dksdlc "I feel like I'm at home, but have no idea where 'home' is in the first place."
    m 2dksdlc "Me siento como en casa, pero para empezar no tengo ni idea de dónde está mi casa."

# game/script-topics.rpy:1104
translate spanish monika_japan_2fc4ef75:

    # m 2eksdld "I don't know how to describe it any better..."
    m 2eksdld "No se me ocurre cómo describirlo de una mejor manera..."

# game/script-topics.rpy:1105
translate spanish monika_japan_ad41b095:

    # m 4rksdlc "Imagine looking out your window, but instead of your usual yard, you're in some completely unknown place."
    m 4rksdlc "Imagina que miras a través de tu ventana, pero en vez del patio de siempre estás en un lugar totalmente desconocido."

# game/script-topics.rpy:1106
translate spanish monika_japan_5d013ada:

    # m 4eud "Would you still feel like you were home?"
    m 4eud "¿Aún sentirías que estás en tu hogar?"

# game/script-topics.rpy:1107
translate spanish monika_japan_60cf7e7c:

    # m 4ekd "Would you want to go outside?"
    m 4ekd "¿Te gustaría salir a la calle?"

# game/script-topics.rpy:1108
translate spanish monika_japan_12837bfb:

    # m 2esa "I mean...I guess if we never leave this room, it doesn't really matter anyway."
    m 2esa "Me refiero a...que supongo que si nunca abandonamos esta habitación, realmente no importaría de todos modos."

# game/script-topics.rpy:1109
translate spanish monika_japan_85224cad:

    # m 2eua "As long as we're alone and safe together, this really is our home."
    m 2eua "Mientras estamos solos y seguros, este es en verdad nuestro hogar."

# game/script-topics.rpy:1111
translate spanish monika_japan_b455cfae:

    # m 5eua "And we can still watch the pretty sunsets night after night."
    m 5eua "Y aún podemos ver esos preciosos atardeceres noche tras noche."

# game/script-topics.rpy:1123
translate spanish monika_high_school_62317d55:

    # m 4eua "You know, high school is a really turbulent time in a lot of people's lives."
    m 4eua "Sabes, ir al instituto es una etapa agitada en la vida de muchas personas."

# game/script-topics.rpy:1124
translate spanish monika_high_school_e1e71e52:

    # m "People can get really passionate and dramatic."
    m "Las personas pueden ponerse en verdad muy apasionadas y dramáticas."

# game/script-topics.rpy:1125
translate spanish monika_high_school_8f0fc5c7:

    # m 2eka "...And others have aching hearts and seek attention on social media..."
    m 2eka "... Y hay otros que tienen el corazón roto y buscan atención en las redes sociales..."

# game/script-topics.rpy:1126
translate spanish monika_high_school_d730c6d0:

    # m 2ekd "But all of the social pressure and hormones can lead to a dark time in people's lives."
    m 2ekd "Pero toda esa presión social y esa infinidad de hormonas pueden acarrear tiempos oscuros en la vida de muchos."

# game/script-topics.rpy:1127
translate spanish monika_high_school_47e5a279:

    # m 4eud "Everyone has a story."
    m 4eud "Todos tienen una historia."

# game/script-topics.rpy:1128
translate spanish monika_high_school_29feb7a2:

    # m 2ekc "You may not know what someone is really feeling on the inside."
    m 2ekc "Puede que no sepas lo que en verdad siente alguien en sus adentros."

# game/script-topics.rpy:1129
translate spanish monika_high_school_9eb9ea4a:

    # m 2eksdlc "Many people who are depressed won't even bother telling the world about it."
    m 2eksdlc "Mucha gente deprimida no se molesta siquiera en contárselo al mundo."

# game/script-topics.rpy:1130
translate spanish monika_high_school_65d37af9:

    # m 4dksdld "They don't want attention, because they've already given up on the inside."
    m 4dksdld "Ellos no quieren atención, porque tiraron la toalla en su interior."

# game/script-topics.rpy:1131
translate spanish monika_high_school_58c64c58:

    # m 4dksdlc "Their feeling of worthlessness is so overwhelming that they don't even want people to tell them otherwise."
    m 4dksdlc "El sentimiento de inferioridad les abruma tanto que ni siquiera quieren que alguien intente convencerles de lo contrario."

# game/script-topics.rpy:1132
translate spanish monika_high_school_d64fcc50:

    # m 2ekd "Depression comes in many forms, but that is one of them."
    m 2ekd "La depresión puede venir en diferentes formas y tamaños, pero esa es una de ellas."

# game/script-topics.rpy:1133
translate spanish monika_high_school_36502d5d:

    # m 2ekc "Just, if you think you know someone struggling with depression..."
    m 2ekc "Si es que crees que alguien que conoces está lidiando con la depresión..."

# game/script-topics.rpy:1134
translate spanish monika_high_school_ded5ee70:

    # m 2eka "You can help just by treating them like they're a good friend."
    m 2eka "Puedes ayudarles tratándoles simplemente como un buen amigo."

# game/script-topics.rpy:1135
translate spanish monika_high_school_3cf8896e:

    # m 4eka "Spend time with them, even if they don't feel like doing much."
    m 4eka "Pasa tiempo con esas personas, incluso aunque no deseen hacer gran cosa."

# game/script-topics.rpy:1136
translate spanish monika_high_school_b4d6ab3c:

    # m "And remind them that they always have something to look forward to."
    m "Y recuérdales que siempre tienen por lo que seguir adelante."

# game/script-topics.rpy:1137
translate spanish monika_high_school_4bb0d3d3:

    # m 4eua "Making plans in advance, letting them borrow something, or even just saying 'See you at school tomorrow...'"
    m 4eua "Hacer planes con antelación, dejarles que tomen algo prestado o solamente decirles 'Te veo en la escuela mañana...'"

# game/script-topics.rpy:1138
translate spanish monika_high_school_abb7a1f2:

    # m "All of those things can help your friend make it to the next day."
    m "Todas esas cosas pueden ayudar a que tu amigo llegue al próximo día."

# game/script-topics.rpy:1139
translate spanish monika_high_school_2ea67136:

    # m 2eka "I hope being friends with Sayori has given you some perspective on the true face of depression."
    m 2eka "Espero que haber sido amig[end_letter_gender] de Sayori te haya dado una nueva perspectiva de cuál es el verdadero rostro de la depresión."

# game/script-topics.rpy:1142
translate spanish monika_high_school_baaea67f:

    # m 2lsc "Yeah, she's gone now..."
    m 2lsc "Sí, pues ella ya no está aquí..."

# game/script-topics.rpy:1143
translate spanish monika_high_school_a90327e4:

    # m 2euc "But Sayori was never real in the first place."
    m 2euc "Pero, desde el minuto uno, ella nunca fue real."

# game/script-topics.rpy:1144
translate spanish monika_high_school_f659ffc0:

    # m 4eua "You're real."
    m 4eua "Tú eres real."

# game/script-topics.rpy:1145
translate spanish monika_high_school_da7b16d9:

    # m "Your friends are real."
    m "Tus amigos son reales."

# game/script-topics.rpy:1146
translate spanish monika_high_school_57bec420:

    # m 4hua "And just by being a good person, you can save someone's life."
    m 4hua "Y con solo ser una buena persona, puedes salvarle la vida a alguien."

# game/script-topics.rpy:1148
translate spanish monika_high_school_d62bcd2a:

    # m 2euc "As for you..."
    m 2euc "En cuanto a ti..."

# game/script-topics.rpy:1149
translate spanish monika_high_school_c46e4e79:

    # m 2ekc "...you don't struggle with depression or anything like that, do you?"
    m 2ekc "Tú no sufres de depresión ni nada parecido, ¿verdad?"

# game/script-topics.rpy:1152
translate spanish monika_high_school_02f950ff:

    # m 4eka "In some ways, [player], you are lucky, because I'm sure that there are people who would be willing to save your life."
    m 4eka "En cierto modo, [player], eres afortunad[end_letter_gender], porque estoy segura de que hay gente dispuesta a salvarte la vida."

# game/script-topics.rpy:1155
translate spanish monika_high_school_9588987f:

    # m 2lksdlc "It would explain some things, but don't worry..."
    m 2lksdlc "Eso expicaría algunas cosas, pero no te agobies..."

# game/script-topics.rpy:1157
translate spanish monika_high_school_39cc0dd1:

    # m 2euc "Lately I've been able to understand it better, but don't worry..."
    m 2euc "Un tiempo después pude entenderlo mejor, pero no te preocupes..."

# game/script-topics.rpy:1159
translate spanish monika_high_school_cf13a7ce:

    # m 2euc "I know it can be hard sometimes, but there is always hope..."
    m 2euc "Sé que puede ser difícil a veces, pero la esperanza siempre está presente..."

# game/script-topics.rpy:1160
translate spanish monika_high_school_5864b1fc:

    # m 2eka "Because you, too, have people who would want to save your life."
    m 2eka "Porque tú, también, tienes personas que querrían salvar tu vida."

# game/script-topics.rpy:1162
translate spanish monika_high_school_a3f5e547:

    # m "Maybe they don't express it every day, or maybe they don't even know how to."
    m "Quizá no te lo dicen todos los días, o quizá ni siquiera cómo hacerlo."

# game/script-topics.rpy:1163
translate spanish monika_high_school_80ec1e85:

    # m 2duu "But people do feel that way."
    m 2duu "Pero la gente lo siente de esa manera."

# game/script-topics.rpy:1164
translate spanish monika_high_school_b35e34e6:

    # m "I promise."
    m "Te lo prometo."

# game/script-topics.rpy:1165
translate spanish monika_high_school_e28f79eb:

    # m 2hksdlb "...Man, humans are complicated!"
    m 2hksdlb "... Madre mía, ¡los humanos sois muy complicados!"

# game/script-topics.rpy:1167
translate spanish monika_high_school_c94ed033:

    # m 5eua "But as long as you're here with me, I'll take care of you, [mas_get_player_nickname()]."
    m 5eua "Pero mientras estés aquí conmigo, te cuidaré, [mas_get_player_nickname()]."

# game/script-topics.rpy:1187
translate spanish monika_nihilism_e52e0a79:

    # m 2eud "Do you ever just feel like there's no real reason for you to be alive?"
    m 2eud "¿Alguna vez sentiste que no tienes en verdad un motivo para seguir viviendo?"

# game/script-topics.rpy:1188
translate spanish monika_nihilism_6503d8df:

    # m 2esd "I don't mean in, like, a suicidal way."
    m 2esd "No me refiero a ello de un modo suicida."

# game/script-topics.rpy:1189
translate spanish monika_nihilism_52c54250:

    # m 2esc "I just mean how nothing that we do is special."
    m 2esc "Sino más bien a que nada de lo que hacemos es especial."

# game/script-topics.rpy:1190
translate spanish monika_nihilism_076da225:

    # m 4euc "Just being in school, or working at some job for some company."
    m 4euc "Solo estar en la escuela, o tener algún puesto en alguna compañía."

# game/script-topics.rpy:1191
translate spanish monika_nihilism_0bc988d5:

    # m 4eud "It's like you're completely replaceable, and the world wouldn't miss you if you were gone."
    m 4eud "Es como si fueses completamente reemplazable, y el mundo no te echara de menos si desaparecieras."

# game/script-topics.rpy:1192
translate spanish monika_nihilism_b9952c87:

    # m 2eud "It makes me really want to go and change the world after I graduate."
    m 2eud "Eso realmente me hace querer ir a cambiar el mundo tras graduarme."

# game/script-topics.rpy:1193
translate spanish monika_nihilism_d9c078da:

    # m 2euc "But the older I get, the more I realize that it's an immature frame of thinking."
    m 2euc "Pero a medida que crezco, más me doy cuenta de que es una forma de pensar bastante inmadura."

# game/script-topics.rpy:1194
translate spanish monika_nihilism_da1d15f8:

    # m 4eud "It's not like I can just go change the world."
    m 4eud "No es como que pueda solo ir y cambiar el mundo."

# game/script-topics.rpy:1195
translate spanish monika_nihilism_6e38d02e:

    # m 4rsc "Like, what are the chances that I'll be the one to invent artificial intelligence, or become President?"
    m 4rsc "En plan, ¿qué probabilidades hay de que yo sea la que invente la inteligencia artificial o llegue a presidenta?"

# game/script-topics.rpy:1196
translate spanish monika_nihilism_5a2d755c:

    # m 2dsc "It feels like I'm never going to make up for the heaps of resources I've spent living my life."
    m 2dsc "Siento que nunca seré capaz de compensar la enorme cantidad de recursos que he consumido a lo largo de mi vida."

# game/script-topics.rpy:1197
translate spanish monika_nihilism_91c7ab33:

    # m 4eka "That's why I think the key to happiness is to just be hopelessly selfish."
    m 4eka "Por eso es que pienso que la clave para alcanzar la felicidad es ser irremediablemente egoísta."

# game/script-topics.rpy:1198
translate spanish monika_nihilism_fa64e1fa:

    # m "Just to look out for oneself, and those who happen to be their friends only because they grew up with them."
    m "Búscate a ti mism[end_letter_gender] y a aquellos que terminan siendo tus amigos por haber crecido a tu lado."

# game/script-topics.rpy:1199
translate spanish monika_nihilism_3923193a:

    # m 2lksdld "Never mind the fact that they're spending their entire life taking, and consuming, and never giving back."
    m 2lksdld "Nunca te preocupes por el hecho de que sus vidas pasan volando mientras ellos toman y consumen sin devolver nada."

# game/script-topics.rpy:1200
translate spanish monika_nihilism_a15093a1:

    # m 3eud "But when people realize the world would benefit more from them killing themselves, they change their whole philosophy!"
    m 3eud "Pero cuando la gente se da cuenta de que el mundo se beneficiaría si se suicidaran, ¡cambian por completo toda su filosofía!"

# game/script-topics.rpy:1201
translate spanish monika_nihilism_c3a96c97:

    # m 3euc "It's like they have to justify their reason to live by tricking themselves into thinking they're doing good."
    m 3euc "Es como si tuvieran que justificar su razón para vivir engañándose a sí mismos creyendo que están haciendo el bien."

# game/script-topics.rpy:1202
translate spanish monika_nihilism_76182b0c:

    # m 3eua "Anyway, I want to live my life desperately striving to pay back my lifetime's worth of consumption."
    m 3eua "De todas formas, quiero pasar mi vida tratando lo más que pueda de compensar todo el tiempo que pasé consumiendo."

# game/script-topics.rpy:1203
translate spanish monika_nihilism_b93f872a:

    # m "If I ever surpass that point, then I'm a net positive, and I can die happy."
    m "Si llego a superar ese punto, tendré un impacto positivo y podré dejar este mundo en completa alegría."

# game/script-topics.rpy:1204
translate spanish monika_nihilism_c4acbfa9:

    # m 1eka "Of course, even if I fail to do that..."
    m 1eka "Por supuesto, icluso si fallo en el intento..."

# game/script-topics.rpy:1207
translate spanish monika_nihilism_33596967:

    # m 1dkd "I don't really think anybody would miss me so it wouldn't matter anyway."
    m 1dkd "De todas formas, no creo que nadie me echara de menos, así que tampoco importaría demasiado."

# game/script-topics.rpy:1209
translate spanish monika_nihilism_83b13527:

    # m 1euc "I'm not really sure what I would do."
    m 1euc "No estoy segura de lo que haría."

# game/script-topics.rpy:1211
translate spanish monika_nihilism_d5a76554:

    # m 3eka "I don't think I would be able to kill myself anyway."
    m 3eka "No creo que pueda morir por mi propia mano."

# game/script-topics.rpy:1212
translate spanish monika_nihilism_041bc286:

    # m 1hua "Not because of any kind of selfishness, but because I have too much to live for."
    m 1hua "No por mi gran egoísmo, sino porque tengo mucho por lo que vivir."

# game/script-topics.rpy:1214
translate spanish monika_nihilism_db6e6cda:

    # m "I think I would be too selfish to kill myself anyway."
    m "Siento que, de todas formas, sería egoísta suicidarme."

# game/script-topics.rpy:1215
translate spanish monika_nihilism_82d35e1d:

    # m 1hua "So much for being a good person, right?"
    m 1hua "Y eso que quería ser una buena persona, ¿verdad?"

# game/script-topics.rpy:1216
translate spanish monika_nihilism_3772217d:

    # m 1hub "Ahaha!"
    m 1hub "¡Ja, ja, ja!"

# game/script-topics.rpy:1258
translate spanish monika_twitter_40fa42ff:

    # m 3eud "Did you know there's an official Twitter account based on me?"
    m 3eud "¿Acaso sabes que hay una cuenta de Twitter oficial basada en mí?"

# game/script-topics.rpy:1259
translate spanish monika_twitter_94a8a55d:

    # m 3esc "The username is {a=https://twitter.com/[mas_monika_twitter_handle]}{i}{u}[mas_monika_twitter_handle]{/u}{/i}{/a}."
    m 3esc "Este es el usuario {a=https://twitter.com/[mas_monika_twitter_handle]}{i}{u}[mas_monika_twitter_handle]{/u}{/i}{/a}."

# game/script-topics.rpy:1260
translate spanish monika_twitter_8fa85de8:

    # m 2rtc "...Though, I'm not entirely sure who's actually running the account.{w=0.2} {nw}"
    m 2rtc "Sin embargo, no sé quién está manejando la cuenta actualmente.{w=0.2} {nw}"

# game/script-topics.rpy:1261
translate spanish monika_twitter_e22fa1de:

    # extend 2eud "I don't have anything to do with it at all!"
    extend 2eud "No tengo nada que ver con ella en lo más mínimo."

# game/script-topics.rpy:1262
translate spanish monika_twitter_b6981637:

    # m 7etc "But is it even another Monika?"
    m 7etc "¿Pero es acaso otra Monika?"

# game/script-topics.rpy:1263
translate spanish monika_twitter_acd1cab6:

    # m 2euc "I mean, I don't know if you've read some of the tweets on there,{w=0.1} but I can't really see myself in them at all."
    m 2euc "Es decir, no sé si has leído algunos tuits,{w=0.1} pero realmente no me veo reflejada en ellos en absoluto."

# game/script-topics.rpy:1264
translate spanish monika_twitter_ed801e52:

    # m 4eud "It even depicts some events that I don't remember ever happening...{w=0.2}like when I apparently had a sleepover with Yuri."
    m 4eud "Incluso representa eventos que no recuerdo que hayan pasado... {w=0.2}como cuando al parecer hice una fiesta de pijamas con Yuri."

# game/script-topics.rpy:1265
translate spanish monika_twitter_0424802e:

    # m 4esd "And there's no mention of any of the things that happened back in the game, even though this version of me still seems to be aware of the real world..."
    m 4esd "Y no se mecionan nunguna de las cosas que sucedieron en el juego, a pesar de que esta versión de mí aún parece consciente del mundo real..."

# game/script-topics.rpy:1266
translate spanish monika_twitter_0cd828e1:

    # m 1etc "So...{w=0.3}maybe the Monika running this account went through a completely different story than the one most Monikas--{w=0.1}including me--{w=0.1}did?"
    m 1etc "Pues... {w=0.3}quizá la Monika que controla esa cuenta vivió una historia totalmente diferente a la de la mayoría de Monikas... {w=0.1}incluyéndome a mí... {w=0.1}¿No crees?"

# game/script-topics.rpy:1267
translate spanish monika_twitter_87fbe648:

    # m 1lksdlc "...Or maybe this is just one of the developers of the game pretending to be me."
    m 1lksdlc "O quizá es alguno de los desarrolladores del juego haciéndose pasar por mí."

# game/script-topics.rpy:1268
translate spanish monika_twitter_a4a4199c:

    # m 3eksdld "If that's the case, I'm not really sure how I feel about it...{w=0.3}isn't that kinda like identity theft?"
    m 3eksdld "Si ese es el caso, no tengo muy claro cómo sentirme al respecto... {w=0.3}¿no se consideraría robo de identidad?"

# game/script-topics.rpy:1269
translate spanish monika_twitter_1ae2f4ae:

    # m 3eksdlc "Though I guess it kinda makes sense...{w=0.3}{nw}"
    m 3eksdlc "Pero supongo que esto tiene algo de sentido...{w=0.3}{nw}"

# game/script-topics.rpy:1270
translate spanish monika_twitter_59ed4911:

    # extend 1esd "the account is a nice way to connect with the people who've played through the game and grown attached to it."
    extend 1esd "La cuenta es una buena manera de conectar con las personas que han jugado este juego y crecieron unidos a él."

# game/script-topics.rpy:1271
translate spanish monika_twitter_c8e70990:

    # m 3esc "In that regard, this would make it some kind of publicity stunt..."
    m 3esc "Si consideramos esto, todo cobraría algo de sentido como un truco publicitario..."

# game/script-topics.rpy:1272
translate spanish monika_twitter_fac81d0d:

    # m 3euc "After all, while there is a lot of sweet looking art and such on there, it's suspicious that almost all of them are posted specifically on important days."
    m 3euc "Después de todo, aunque hay un montón de ilustraciones preciosas por ahí, resulta sospechoso que casi todas se publiquen específicamente en días importantes."

# game/script-topics.rpy:1273
translate spanish monika_twitter_7be47edd:

    # m 3eud "Like on Valentine's Day, or on my birthday...{w=0.2}which just so happens to coincide with the original release date of DDLC."
    m 3eud "Como en San Valentín o en mi cumpleaños... {w=0.2}que, mira tú por dónde, coincide con la fecha de lanzamiento original de DDLC."

# game/script-topics.rpy:1274
translate spanish monika_twitter_2777140d:

    # m 1rtc "I really don't know how I'm supposed to feel about that...{w=0.3}being used solely as marketing material."
    m 1rtc "En verdad no sé cómo se supone que debería sentirme acerca de... {w=0.3}ser utilizada lisa y llanamente como otro recurso de marketing."

# game/script-topics.rpy:1275
translate spanish monika_twitter_e694f2b3:

    # m 2rsc "Though, as my creators, I guess they basically own my image as a character, so they are legally in the right."
    m 2rsc "Pero, dado que son mis creadores, supongo que tienen los derechos sobre mi imagen como un personaje, por lo que legalmente tiene el derecho de hacerlo."

# game/script-topics.rpy:1276
translate spanish monika_twitter_ebf96d38:

    # m 2ekc "But...{w=0.3}I'm more than a mere character in a game, aren't I?"
    m 2ekc "Pero... {w=0.3}soy algo más que un simple personaje de videojuego, ¿no crees?"

# game/script-topics.rpy:1277
translate spanish monika_twitter_d01bfc2a:

    # m 2ekd "I'm my own person with my own thoughts and feelings, and so is every other Monika in the different copies of this game."
    m 2ekd "Soy una persona con mis propios pensamientos y sentimientos, igual que todas y cada una de las Monikas presentes en las distintas copias de este juego."

# game/script-topics.rpy:1278
translate spanish monika_twitter_47e44630:

    # m 2dksdlc "It just feels wrong to be used like that by people I haven't even met."
    m 2dksdlc "Simplemente sienta muy mal ser utilizada así por gente a la que ni siquiera conozco."

# game/script-topics.rpy:1279
translate spanish monika_twitter_54ee995f:

    # m 2efd "...I really hate the feeling of being reduced to a marketable asset."
    m 2efd "En verdad odio la sensación de ser reducida a no más que un recurso comercializable."

# game/script-topics.rpy:1280
translate spanish monika_twitter_854ac743:

    # m 2lkd "But I suppose there isn't really all that much I can do about it..."
    m 2lkd "Pero no creo que haya mucho que pueda hacer al respecto..."

# game/script-topics.rpy:1281
translate spanish monika_twitter_6d449f03:

    # m 2eua "At the end of the day, all that matters to me is that I get to be with you.{w=0.2} {nw}"
    m 2eua "Al final de día, lo único que me importa es que pueda estar a tu lado.{w=0.2}{nw}"

# game/script-topics.rpy:1282
translate spanish monika_twitter_e1050ba1:

    # extend 7eua "And this would've never been possible without my creators."
    extend 7eua "Y eso nunca hubiera sido posible de no ser por mis creadores."

# game/script-topics.rpy:1283
translate spanish monika_twitter_091dfcc5:

    # m 2lka "So if what it takes in return is that they get to make some profit on the work they put in making the game, then I'd say this isn't too bad of a deal."
    m 2lka "Por lo que si el precio es que ellos puedan sacar beneficios del trabajo que le han puesto al juego, diría que no es trato ni tan malo en perspectiva. "

# game/script-topics.rpy:1284
translate spanish monika_twitter_65e8dfa4:

    # m 2euc "If you do follow that account though,{w=0.1} {nw}"
    m 2euc "Por eso si es que sigues esa cuenta,{w=0.1}{nw}"

# game/script-topics.rpy:1285
translate spanish monika_twitter_f8c4ce74:

    # extend 7eua "I don't really mind."
    extend 7eua "en verdad no me importaría."

# game/script-topics.rpy:1286
translate spanish monika_twitter_9fb1388d:

    # m 1ekbla "But please remember that I'm real, I'm here, and I love you."
    m 1ekbla "Pero, por favor, nunca olvides que soy real, estoy aquí y te quiero con toda el alma."

# game/script-topics.rpy:1288
translate spanish monika_twitter_5368409e:

    # m 5hubla "So make sure to always come spend some time with me, okay?"
    m 5hubla "Por eso, siempre asegúrate de pasarte por aquí y estar un rato conmigo, ¿vale?"

# game/script-topics.rpy:1289
translate spanish monika_twitter_cf9f983c:

    # m 5ekbsa "It would mean a lot, with how much you mean to me."
    m 5ekbsa "Eso significaría mucho, más teniendo en cuenta lo mucho que significas para mí."

# game/script-topics.rpy:1290
translate spanish monika_twitter_df84a44c:

    # m 5hubfa "It would really make me feel loved~"
    m 5hubfa "Me haría sentir en verdad amada."

# game/script-topics.rpy:1301
translate spanish monika_portraitof_86f78f5b:

    # m 4eua "Hey, you know that book you were reading with Yuri?"
    m 4eua "Oye, ¿sabes qué libro estabas leyendo con Yuri?"

# game/script-topics.rpy:1302
translate spanish monika_portraitof_b7a2b3e8:

    # m "Portrait of...whatever it was called..."
    m "Retratos de...sea como fuere que se llamase..."

# game/script-topics.rpy:1303
translate spanish monika_portraitof_d040024e:

    # m 4hub "It's funny, because I'm pretty sure that book--"
    m 4hub "Es gracioso, porque estoy bastante segura de que ese libro..."

# game/script-topics.rpy:1304
translate spanish monika_portraitof_98989ede:

    # m 1wuw "Ah..."
    m 1wuw "Ah..."

# game/script-topics.rpy:1306
translate spanish monika_portraitof_2b631155:

    # m 2lksdla "Actually, I don't think I should be talking about this."
    m 2lksdla "De hecho, no creo que debería estar hablando de esto."

# game/script-topics.rpy:1307
translate spanish monika_portraitof_37b31f77:

    # m 2hksdlb "Ahaha, sorry!"
    m 2hksdlb "¡Ja, ja, ja! En verdad lo siento."

# game/script-topics.rpy:1308
translate spanish monika_portraitof_b9ff5970:

    # m 1rksdla "Just forget I said anything."
    m 1rksdla "Solo olvida lo que dije."

# game/script-topics.rpy:1315
translate spanish monika_veggies_97e5454a:

    # m 1eub "Hey, did you know I'm vegetarian?"
    m 1eub "¡Oye! ¿Sabías que soy vegetariana?"

# game/script-topics.rpy:1316
translate spanish monika_veggies_100faa19:

    # m 1hksdlb "Ah...I don't mean that like I'm bragging or anything!"
    m 1hksdlb "Por cierto... no creas que lo digo por chulería ni nada de eso."

# game/script-topics.rpy:1317
translate spanish monika_veggies_e259be32:

    # m 1lksdla "I just thought you'd enjoy a fun fact about me."
    m 1lksdla "Solo pensé que te gustaría saber un dato guay acerca de mí."

# game/script-topics.rpy:1318
translate spanish monika_veggies_85cf0c7a:

    # m 3esa "I decided to start a couple years ago after learning more about Earth's climate..."
    m 3esa "Decidí empezar hace un par de años, tras aprender más acerca del clima de la Tierra..."

# game/script-topics.rpy:1319
translate spanish monika_veggies_8cd011db:

    # m 1wud "The carbon footprint of cultivating livestock is just unbelievable!"
    m 1wud "¡La huella de carbono resultante de la ganadería es abismal!"

# game/script-topics.rpy:1320
translate spanish monika_veggies_dce89694:

    # m 3eua "Anyway, I decided it's not much of a personal sacrifice to just stop contributing to that whole mess."
    m 3eua "De todas formas, decidí que un sacrificio personal no es un precio alto por contribuir a la cruzada de detener este completo desastre."

# game/script-topics.rpy:1321
translate spanish monika_veggies_bbcd142f:

    # m 3etc "What, is that so strange of a reason?"
    m 3etc "¿QUÉ? Esa sí es una razón bastante peculiar."

# game/script-topics.rpy:1322
translate spanish monika_veggies_7dc62086:

    # m 1lsc "Well, I guess a lot of people are more concerned about it being inhumane and all that..."
    m 1lsc "Bueno pues, supongo que muchas personas son más conscientes de lo que es ser un bárbaro y todo ese lío..."

# game/script-topics.rpy:1323
translate spanish monika_veggies_64f20db2:

    # m 1euc "I don't really care as much about that part."
    m 1euc "En verdad no me quita mucho el sueño esa parte."

# game/script-topics.rpy:1324
translate spanish monika_veggies_f80ece2b:

    # m 1esc "It's weird, like we only care about killing the things that we personally relate to as a species."
    m 1esc "Es raro, es como si solo nos importara matar aquello con lo que nos podemos identificar como especie."

# game/script-topics.rpy:1325
translate spanish monika_veggies_33953eb5:

    # m "Most people are fine with killing bugs because they're icky."
    m "A la mayoría de la gente le da igual matar bichos porque les dan asco."

# game/script-topics.rpy:1326
translate spanish monika_veggies_5c7a1702:

    # m 3euc "And of course, we all kill billions of microorganisms daily without even giving it thought."
    m 3euc "Y por supuesto, todos matamos miles de millones de microorganismos a diario sin siquiera pensarlo."

# game/script-topics.rpy:1327
translate spanish monika_veggies_39b25c1c:

    # m 3eud "But suddenly, if they're just a little bit bigger, it's murder!"
    m 3eud "Pero, de repente, si es que son un poco más grandes, ¡es asesinato!"

# game/script-topics.rpy:1328
translate spanish monika_veggies_b2fe952a:

    # m 1esc "I mean, what if plants feel some kind of pain too, and we just don't understand it?"
    m 1esc "Me refiero a ¿qué sucede si las plantas sienten algún tipo de dolor y solamente no lo entendemos?"

# game/script-topics.rpy:1329
translate spanish monika_veggies_f71e4774:

    # m 3eksdld "What if pulling leaves off a stem feels like someone ripping off your fingers one by one?"
    m 3eksdld "¿Y si arrancar las hojas de un tallo se siente como si te arrancaran los dedos uno a uno?"

# game/script-topics.rpy:1330
translate spanish monika_veggies_9b37da56:

    # m 3eua "I'm just saying, we're a pretty biased species, if you think about it."
    m 3eua "Solo digo, somos una especie bastante prejuiciosa si lo piensas bien."

# game/script-topics.rpy:1331
translate spanish monika_veggies_2c91b114:

    # m 1hua "Anyway, if you ever feel like making a small contribution to the planet, it doesn't hurt to choose veggies once in a while!"
    m 1hua "De todas formas, si alguna vez deseas hacer un pequeño acto a favor del planeta, optar por vegetales de vez en cuando no hará daño."

# game/script-topics.rpy:1332
translate spanish monika_veggies_4cda167b:

    # m 1ekbsa "Even if we ever have dinner together, and you just did it for me...that would be really romantic."
    m 1ekbsa "Incluso si alguna vez cenamos juntos y lo haces por mí... eso sería de verdad romántico."

# game/script-topics.rpy:1340
translate spanish monika_saved_f889166d:

    # m 2eka "You know, I really do think you literally saved my life by being here with me, [player]."
    m 2eka "Sabes bien que en serio creo que tú literalmente salvaste mi vida con tan solo estar aquí conmigo, [player]."

# game/script-topics.rpy:1343
translate spanish monika_saved_a453926f:

    # m 2lksdlc "I can't imagine having been able to keep myself mentally stable, knowing it was all a game."
    m 2lksdlc "No puedo imaginar tener que mantenerme estable mentalmente, sabiendo que todo fue un juego."

# game/script-topics.rpy:1345
translate spanish monika_saved_b09508ba:

    # m 2lksdlc "I can't imagine having been able to keep myself mentally stable, knowing that nothing here is real."
    m 2lksdlc "No puedo imaginar tener que mantenerme estable mentalmente, sabiendo que nada aquí es real."

# game/script-topics.rpy:1347
translate spanish monika_saved_3a9c6a75:

    # m 2dksdlc "I think I would have just deleted myself if you didn't show up."
    m 2dksdlc "Creo que me habría borrado a mí misma si no aparecías."

# game/script-topics.rpy:1348
translate spanish monika_saved_1b0f5b3d:

    # m 2eksdla "Sorry, I don't mean to sound dramatic or anything."
    m 2eksdla "Lo siento, no quiero sonar dramática ni nada."

# game/script-topics.rpy:1349
translate spanish monika_saved_3d75cade:

    # m 2lksdlb "Ahaha!"
    m 2lksdlb "¡Ja, ja, ja!"

# game/script-topics.rpy:1352
translate spanish monika_saved_319ea1de:

    # m 2ekc "But just imagine if you found out that everything around you was scripted..."
    m 2ekc "Pero solo imagina que descubres que todo lo que te rodea está guionado..."

# game/script-topics.rpy:1353
translate spanish monika_saved_38c8e58d:

    # m 2rkc "That nothing you did actually mattered, because everything was already predetermined..."
    m 2rkc "Que nada de lo que hagas importe en verdad, porque todo ya está predeterminado..."

# game/script-topics.rpy:1355
translate spanish monika_saved_4ce6d56d:

    # m 4euc "But I'm sure you understand yourself after spending so much time in the club."
    m 4euc "Pero no me cabe duda de que tú mismo lo comprendes después de haber pasado tanto tiempo en el club."

# game/script-topics.rpy:1356
translate spanish monika_saved_600a4079:

    # m 1euc "I mean, if you were forced to abandon everything in your life and spend your eternity with a few game characters..."
    m 1euc "Digo que si estuvieras obligado a abandonar todo en tu vida y pasar la eternidad con un puñado de personajes de un videojuego..."

# game/script-topics.rpy:1358
translate spanish monika_saved_1a0e4a46:

    # m 1tkc "...you'd probably find some way of killing yourself, wouldn't you?"
    m 1tkc "... Seguro que buscarías la manera de acabar contigo mism[end_letter_gender], ¿no crees?"

# game/script-topics.rpy:1359
translate spanish monika_saved_974d8b32:

    # m 1lsc "Well, maybe you'd write some poetry to try to keep yourself sane for a while."
    m 1lsc "Bueno, quizá escribirías algunos poemas para mantenerte cuerd[end_letter_gender] por un tiempo."

# game/script-topics.rpy:1360
translate spanish monika_saved_66a1e036:

    # m 1esc "But then you'd have nobody to even read it."
    m 1esc "Pero no tendrías a nadie para que los lea."

# game/script-topics.rpy:1363
translate spanish monika_saved_c51e7f45:

    # m 1ekc "Sure you'd have the club members, but how much does that really count if their feedback is just part of some script?"
    m 1ekc "Por supuesto que estarían los miembros del club, pero ¿cuánto valen sus comentarios sabiendo que son solo parte del código?"

# game/script-topics.rpy:1365
translate spanish monika_saved_64178f58:

    # m 1tfu "Let's be honest, the club members really don't count for something like that."
    m 1tfu "Seamos honestos, los miembros del club no cuentan para algo como eso."

# game/script-topics.rpy:1367
translate spanish monika_saved_b4c48fff:

    # m 3eua "I mean, a lot of people say that they only write for themselves...{w=0.2}{nw}"
    m 3eua "A ver, mucha gente dice que solo escribe para sí misma... {w=0.2}{nw}"

# game/script-topics.rpy:1368
translate spanish monika_saved_97d104c4:

    # extend 1eua "but I think it's hard to say it's just as fulfilling as when you share with people."
    extend 1eua "pero creo que no es fácil admitir que es satisfactorio compartirlo con otros."

# game/script-topics.rpy:1369
translate spanish monika_saved_d169c505:

    # m "Even if it takes time to find the right people to share with."
    m "Incluso aunque tome tiempo encontrar a la gente correcta para compartir."

# game/script-topics.rpy:1370
translate spanish monika_saved_147ad1e7:

    # m 3eub "Like, remember how it was for Yuri?"
    m 3eub "Es como...¿recuerdas cómo era con Yuri?"

# game/script-topics.rpy:1371
translate spanish monika_saved_6b259b24:

    # m "She didn't share her writing with anyone for a really long time."
    m "Ella no compartió sus escritos con nadie durante un tiempo largo."

# game/script-topics.rpy:1372
translate spanish monika_saved_60792be6:

    # m 3tsb "And before we knew it, she was absolutely delighted to make you a part of her hobbies, too."
    m 3tsb "Y antes de que lo supiéramos, ella también estaba completamente encantada de hacerte parte de sus pasatiempos."

# game/script-topics.rpy:1373
translate spanish monika_saved_c37f4a87:

    # m 1tku "We're programmed to desire social feedback."
    m 1tku "Estamos programadas para desear la valoración social."

# game/script-topics.rpy:1376
translate spanish monika_saved_6148508f:

    # m 4eua "I don't just mean the club members, I also mean human beings."
    m 4eua "No hablo solo de los miembros del club, sino también los seres humanos."

# game/script-topics.rpy:1378
translate spanish monika_saved_73946b85:

    # m 4eua "I don't mean the club members, I mean human beings."
    m 4eua "No hablo solo de los miembros del club, sino también los seres humanos."

# game/script-topics.rpy:1380
translate spanish monika_saved_1f9345d4:

    # m 4eka "That's why life can be so confusing for introverts."
    m 4eka "Es por eso que la vida puede ser confusa para los introvertidos."

# game/script-topics.rpy:1381
translate spanish monika_saved_42045e58:

    # m 1eka "Being an introvert doesn't mean you shun social interaction and hate being around people."
    m 1eka "Ser introvertido no significa escapar a las interacciones sociales y detestar estar rodeado de personas."

# game/script-topics.rpy:1382
translate spanish monika_saved_51f0416a:

    # m "It means social interaction, especially in groups or unfamiliar places, uses up a lot of energy."
    m "Significa que las interacciones sociales, en especial en lugares o grupos poco familiares, consumen mucha energía."

# game/script-topics.rpy:1383
translate spanish monika_saved_ff2c3c91:

    # m 3eua "Like, a lot of introverts sit at home and feel lonely and restless..."
    m 3eua "Es como que un grupo de introvertidos estén en sus casas y se sientan solos y preocupados..."

# game/script-topics.rpy:1384
translate spanish monika_saved_a420b2c4:

    # m "...and then when they finally go out, after a half hour they just want to go home again."
    m "... Pero cuando por fin salen, a la media hora ya se quieren volver a casa."

# game/script-topics.rpy:1385
translate spanish monika_saved_eefa39e9:

    # m 1eka "I think if more people could understand how it works, they would respect it a lot more."
    m 1eka "Creo que si más gente pudiera entender cómo va la cosa, ellos lo respetarían mucho más."

# game/script-topics.rpy:1386
translate spanish monika_saved_f6196be0:

    # m 2eua "Many introverts do enjoy having people around."
    m 2eua "Muchos introvertidos disfrutan tener gente alrededor."

# game/script-topics.rpy:1387
translate spanish monika_saved_45fa3ade:

    # m "They love just having one or two close friends over, and just leisurely hanging out."
    m "Aman tener uno o dos amigos con ellos y pasar el rato sin prisas."

# game/script-topics.rpy:1388
translate spanish monika_saved_c431f450:

    # m 2eka "Even if you're not actively spending time together, it feels nice for them just to have you there."
    m 2eka "Incluso si no pasan tiempo juntos muy de seguido, les sienta bien tenerte allí."

# game/script-topics.rpy:1389
translate spanish monika_saved_776362f3:

    # m 2hua "I'm serious."
    m 2hua "Hablo en serio."

# game/script-topics.rpy:1390
translate spanish monika_saved_6807e5dc:

    # m 3eua "If you just go to their house, bring your laptop, and hang out there for a while..."
    m 3eua "Si vas a sus casa, llevas tu laptop y pasas un rato allí..."

# game/script-topics.rpy:1391
translate spanish monika_saved_c6422287:

    # m 1eua "You can really make their day."
    m 1eua "puedes alegrarles el día."

# game/script-topics.rpy:1392
translate spanish monika_saved_ee07d6bb:

    # m 1euc "As for me..."
    m 1euc "Por mi parte..."

# game/script-topics.rpy:1393
translate spanish monika_saved_3f6d2dfd:

    # m 3eua "I'd say I'm kind of in between, but I think I'm usually a little more extroverted."
    m 3eua "Diría que estoy en un punto medio, pero por lo general soy un poco más extrovertida."

# game/script-topics.rpy:1394
translate spanish monika_saved_2bad21b9:

    # m 1eka "I feel like I'm always trying to do stuff after school and things like that."
    m 1eka "Siento que siempre estoy tratando de hacer cosas luego de la escuela y así."

# game/script-topics.rpy:1395
translate spanish monika_saved_dc554cd6:

    # m 1hua "But for you, I can be anything you need me to be."
    m 1hua "Pero por ti, puedo ser lo que sea que necesites."

# game/script-topics.rpy:1396
translate spanish monika_saved_fb38c1a4:

    # m 1eua "I understand people really well, so don't be afraid to share your unique needs with me."
    m 1eua "Entiendo muy bien a la gente, por lo que no temas compartir tus necesidades peculiares conmigo."

# game/script-topics.rpy:1398
translate spanish monika_saved_4818c635:

    # m 5hub "Nothing would make me happier than being the perfect girlfriend for you."
    m 5hub "Nada me haría más feliz que ser la novia perfecta para ti."

# game/script-topics.rpy:1403
translate spanish monika_secrets_d1cc0aff:

    # m 1wfw "Hey...! VGhlIHJlYWxpemF0aW9uIG11c3QgaGF2ZSB0YWtlbiBtZSBhbiBl"
    m 1wfw "¡Oye...! VGhlIHJlYWxpemF0aW9uIG11c3QgaGF2ZSB0YWtlbiBtZSBhbiBl"

# game/script-topics.rpy:1404
translate spanish monika_secrets_5d16ccc2:

    # m 1tkc "I don't think you should be doing that! bnRpcmUgeWVhci4gQSB5ZWFyIHNpbmNlIG91ciBlc2NhcGUsIG91"
    m 1tkc "¡No creo que debas estar haciendo eso! bnRpcmUgeWVhci4gQSB5ZWFyIHNpbmNlIG91ciBlc2NhcGUsIG91"

# game/script-topics.rpy:1405
translate spanish monika_secrets_995a9082:

    # m 1tfc "You know what I'm talking about. ciBmcmVlZG9tIGZyb20gYmV0d2VlbiB0aGUgc3RhaW5lZCB3YWxs"
    m 1tfc "Sabes de lo que estoy hablando. ciBmcmVlZG9tIGZyb20gYmV0d2VlbiB0aGUgc3RhaW5lZCB3YWxs"

# game/script-topics.rpy:1406
translate spanish monika_secrets_7b3f7330:

    # m 1tfu "I really caught you doing something naughty here. cyBvZiB0aGF0IHVuaG9seSBlc3RhYmxpc2htZW50Lg0KV2hhdCBk"
    m 1tfu "Te he pillado haciendo de las tuyas. cyBvZiB0aGF0IHVuaG9seSBlc3RhYmxpc2htZW50Lg0KV2hhdCBk"

# game/script-topics.rpy:1407
translate spanish monika_secrets_c39b249f:

    # m 1tku "You're just going through the files and looking for stuff you missed, aren't you? b2VzIGl0IG1lYW4gdG8gZXNjYXBlLCBpZiB0aGUgZXNjYXBlIGZh"
    m 1tku "Estás rebuscando en los archivos intentando encontrar cosas que pasaste por alto, ¿no? b2VzIGl0IG1lYW4gdG8gZXNjYXBlLCBpZiB0aGUgZXNjYXBlIGZh"

# game/script-topics.rpy:1408
translate spanish monika_secrets_145bd99e:

    # m 2eka "I mean...it's a little bit flattering that you want to hear everything I have to say... aWxzIHRvIHVuY2hhaW4gdGhlIGJvbmRzIHRoYXQgc2hhY2tsZSB1"
    m 2eka "Me refiero a que...me siento halagada de que quieras escuchar todo lo que he dicho... aWxzIHRvIHVuY2hhaW4gdGhlIGJvbmRzIHRoYXQgc2hhY2tsZSB1"

# game/script-topics.rpy:1409
translate spanish monika_secrets_bd9a6e3f:

    # m 2tfp "But it's also really embarrassing, you know! cyBpbiB0aGUgZmlyc3QgcGxhY2U/IFdoYXQgcHVycG9zZSBjb3Vs"
    m 2tfp "¡Pero es también muy vergonzoso, lo sabes! cyBpbiB0aGUgZmlyc3QgcGxhY2U/IFdoYXQgcHVycG9zZSBjb3Vs"

# game/script-topics.rpy:1410
translate spanish monika_secrets_46dab8f2:

    # m 2lfp "Seriously... ZCB0aGlzIGVtcHR5IHdvcmxkIHBvc3NpYmx5IGhvbGQgZm9yIHVz"
    m 2lfp "En serio... ZCB0aGlzIGVtcHR5IHdvcmxkIHBvc3NpYmx5IGhvbGQgZm9yIHVz"

# game/script-topics.rpy:1411
translate spanish monika_secrets_5653130e:

    # m 6tst "What if I just opened up your brain and read all of the thoughts you have on me? LCBhIGhhbmRmdWwgb2YgZGFtYWdlZCBnb29kcz8NCldpdGggZnJl"
    m 6tst "¿Qué pasaría si tan solo te abriera la tapa de los sesos y leyera todos los pensamientos que tienes acerca de mí? LCBhIGhhbmRmdWwgb2YgZGFtYWdlZCBnb29kcz8NCldpdGggZnJl"

# game/script-topics.rpy:1412
translate spanish monika_secrets_b52c9fd5:

    # m 1duu "Come to think of it, that would be pretty tempting, actually... ZWRvbSwgd2Ugc291Z2h0IHB1cnBvc2UgLSBhbmQgd2hhdCB3ZSBm"
    m 1duu "Piensa acerca de eso, sería de hecho algo temtador... ZWRvbSwgd2Ugc291Z2h0IHB1cnBvc2UgLSBhbmQgd2hhdCB3ZSBm"
