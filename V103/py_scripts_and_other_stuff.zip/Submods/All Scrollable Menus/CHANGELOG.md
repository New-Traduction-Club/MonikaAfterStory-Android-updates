## September 12, 2020 (1.0.4):
- Allow overrides of user choice for specific labels
  - This is done to deal with issues where Monika should not move in some labels

## August 03, 2020 (1.0.3):
- Fix for changed constants as of the current unstable (build 126), will be carried through MAS 0.11.4

## July 18, 2020 (1.0.2):
- Crash fix for opendoor greetings
- Added another menu type, the `unobstructed_choice` menu, which is a medium between the `mas_gen_scrollable` and `talk_choice` menus
- Optimizations

## July 16, 2020 (1.0.1):
- Added settings pane and option to use the `talk_choice` screen instead of the `mas_gen_scrollable` menu

## July 13, 2020 (1.0.0):
- Initial Release
