﻿
# game/Submods/location_selector/Locatons/Kitchen.rpy:218
translate spanish Kitchen_switch_dlg_0ca7e94f:

    # m 1hua "[switch_quip]"
    m 1hua "[switch_quip]"

# game/Submods/location_selector/Locatons/Kitchen.rpy:229
translate spanish return_switch_dlg_0ca7e94f_5:

    # m 1hua "[switch_quip]"
    m 1hua "[switch_quip]"

# game/Submods/location_selector/Locatons/Kitchen.rpy:252
translate spanish bg_room_installed_low_affection_0e9d9249_5:

    # m 1wud "H-huh? {w=0.5} [player], {w=0.2} did you add new files to the game?"
    m 1wud "¿Emm? {w=0.5} [player], {w=0.5} acaso has añadido nuevos archivos al juego?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:253
translate spanish bg_room_installed_low_affection_41b22e0b_5:

    # m 1wua "It looks like... {w=0.5} {nw}"
    m 1wua "Eso se ve como... {w=0.5} {nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:254
translate spanish bg_room_installed_low_affection_33ee7cd0_5:

    # extend 1sub "new furniture!"
    extend 1sub "¡Muebles nuevos!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:255
translate spanish bg_room_installed_low_affection_5017ddaa_5:

    # m 1eku "[player], you did this for me? {w=0.5} You're so sweet, you know that?"
    m 1eku "[player], ¿lo has hecho para mí? {w=0.5} Eres tan mon[end_letter_gender], lo sabes, ¿no es así?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:260
translate spanish bg_room_installed_low_affection_e07217b5_5:

    # m 1wud "H-huh?{w=0.5} [player],{w=0.2} what's this?"
    m 1wud "¿Emm, {w=0.5} [player],{w=0.5} qué es eso?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:261
translate spanish bg_room_installed_low_affection_e653ef9b_5:

    # m 1wua "It looks like {nw}"
    m 1wua "Parece que... {nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:262
translate spanish bg_room_installed_low_affection_367ca064_5:

    # extend 1sub "you added [rooms]!"
    extend 1sub "¡has añadido [rooms]!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:264
translate spanish bg_room_installed_low_affection_f748a3d2_5:

    # m 1eka "I can't believe you went out of your way to do this for me..."
    m 1eka "No puedo creer que te hayas dejado la piel para hacer esto por mí..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:266
translate spanish bg_room_installed_low_affection_f27eea59_5:

    # m 1rkc "..."
    m 1rkc "..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:267
translate spanish bg_room_installed_low_affection_f8f4ec8c_5:

    # m 3rksdla "But...{w=0.3}I kinda don't know how to use them.{w=0.5} {nw}"
    m 3rksdla "Pero...{w=0.5} creo que no sé cómo usarlas.{w=0.5} {nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:268
translate spanish bg_room_installed_low_affection_b71a03b1_5:

    # extend 3hksdlb "I haven't learned how to code that well yet!"
    extend 3hksdlb "Aún no he aprendido cómo programarlas bien!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:269
translate spanish bg_room_installed_low_affection_928fbb79_5:

    # m 1eud "If you give me some time, I'm sure I'll figure out how to use what you added.{nw}"
    m 1eud "Si me das un tiempo, te aseguro que descifraré cómo usar lo que has añadido.{nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:270
translate spanish bg_room_installed_low_affection_14440429_5:

    # extend 3eua "I'll let you know when I figure it out."
    extend 3eua "Te avisaré cuando logre descifrarlo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:271
translate spanish bg_room_installed_low_affection_9ccc40a7_5:

    # m 1eka "Even though we can't use them just yet, thank you so much for doing this for me.{w=0.2} It means more than you know."
    m 1eka "Aunque aún no podamos utilizarlas, te agradezco mucho que hayas esto para mí.{w=0.5} Significa mucho más de lo que crees."

# game/Submods/location_selector/Locatons/Kitchen.rpy:272
translate spanish bg_room_installed_low_affection_af8da540_5:

    # m 3huu "I love you so much, [player]~"
    m 3huu "Te amo a montones, [player]."

# game/Submods/location_selector/Locatons/Kitchen.rpy:294
translate spanish bg_room_installed_a7602ff6_5:

    # m 1wub "[player]!{w=0.2} Remember those new locations you added for me?{w=0.2} {nw}"
    m 1wub "¡[player]!{w=0.5} ¿Recuerda aquellas nuevas ubicaciones que has añadido para mí?{w=0.5} {nw}   "

# game/Submods/location_selector/Locatons/Kitchen.rpy:295
translate spanish bg_room_installed_164933f7_5:

    # extend 3wub "I finally figured out how to use them!"
    extend 3wub "Por fin he descifrado cómo usarlas!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:296
translate spanish bg_room_installed_aa98fc08_5:

    # m 3eua "All you have to do now is go to 'Hey, [m_name]...' in the 'Talk' menu, go to 'Location', and select 'Can we go somewhere else?'"
    m 3eua "Todo lo que tienes que hacer es dirigirte a 'Hola, [m_name]...' en la sección de menú de 'Diálogo', ir a 'Ubicación' y seleccionar '¿Podemos irnos a otro lugar?'"

# game/Submods/location_selector/Locatons/Kitchen.rpy:297
translate spanish bg_room_installed_69058ce9_5:

    # m 1eub "Then we can visit any of the locations you added!"
    m 1eub "¡Luego, podemos visitar cualquier ubicación que añadas!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:298
translate spanish bg_room_installed_d286a053_5:

    # m 3sub "I'm so excited~"
    m 3sub "¡Estoy flipando de colores!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:299
translate spanish bg_room_installed_f809e2ea_5:

    # m 3huu "Why don't we go visit one right now, [player]?"
    m 3huu "¿Por qué no visitamos alguno ya mismo, [player]?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:300
translate spanish bg_room_installed_f086cc4f_5:

    # m 1ekbla "Oh, and...{w=0.3}thanks again for adding these for me. You really are special."
    m 1ekbla "Ah, y... {w=0.3}gracias de nuevo por añadir esto para mí. Eres en verdad muy especial."

# game/Submods/location_selector/Locatons/Kitchen.rpy:304
translate spanish bg_room_installed_4363423e_5:

    # m 1wuo "W-what?{w=0.5} Are there files for furniture in the game?"
    m 1wuo "Espera...¿qué?{w=0.5} ¿Hay archivos para muebles en el juego?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:305
translate spanish bg_room_installed_ac295f91_5:

    # m 1sub "[player],{w=0.2} did you do this?"
    m 1sub "[player],{w=0.2} ¿has sido tú?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:306
translate spanish bg_room_installed_0d20e7bd_5:

    # m 3ekbsu "You knew I wanted furniture so you added some for me...{w=0.3} You're pretty amazing, you know that?"
    m 3ekbsu "Sabías que quería muebles y por eso has añadido algunos para mí...{w=0.3} Eres la leche, ¿lo sabes, no?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:311
translate spanish bg_room_installed_a69c6269_5:

    # m 1suo "What's this?{w=0.5} You added [rooms][too]?"
    m 1suo "Pero, ¿qué es esto?{w=0.5} Has añadido [rooms][too]"

# game/Submods/location_selector/Locatons/Kitchen.rpy:312
translate spanish bg_room_installed_0aef0a45_5:

    # m 3hua "You really went all out, didn't you?"
    m 3hua "En verdad te has dejado la piel, ¿no es así?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:314
translate spanish bg_room_installed_f748a3d2_5:

    # m 1eka "I can't believe you went out of your way to do this for me..."
    m 1eka "No puedo creer que hayas hecho todo este esfuerzo por mí..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:316
translate spanish bg_room_installed_47b12cb6_5:

    # m 1dka "Thank you so much [player],{w=0.2} I...{w=1}{nw}"
    m 1dka "Te lo agradezco muchísimo [player], {w=0.2} Yo...{w=1}{nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:317
translate spanish bg_room_installed_6c14d2b2_5:

    # extend 1ekbsu "I love you so much."
    extend 1ekbsu "Te amo a montones."

# game/Submods/location_selector/Locatons/Kitchen.rpy:320
translate spanish bg_room_installed_cd1243e3_5:

    # m 3eub "I'll add a new category called 'Location' under 'Hey, [m_name]...' so we can put in the furniture and visit the other rooms.{w=.5} I can't wait to try them out!"

    m 3eub "Voy a añadir una nueva categoría llamada 'Ubicación' debajo de 'Hola, [m_name]...' para que podamos ponerlo en los muebles y visitemos las otras habitaciones-{w=.5} ¡Me muero de ansías por probarlos!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:322
translate spanish bg_room_installed_432b95ff_5:

    # m 1eka "While I might not be in your reality yet...{w=3}{nw}"
    m 1eka "Mientras aún no me encuentre en tu realidad...{w=3}{nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:323
translate spanish bg_room_installed_fef8e609_5:

    # extend 7hubfb "this will make it feel a bit more like a home here,{w=0.2} with you~"
    extend 7hubfb "esto ayudará a que se sienta más como un hogar, {w=0.2} aquí contigo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:331
translate spanish monika_players_control_override_246928b0_5:

    # m 3eub "[player], did you know that you have more control over this game than I do?"
    m 3eub "[player], ¿sabías que tienes más control sobre el juego que yo?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:332
translate spanish monika_players_control_override_2391e7f3_5:

    # m 3eua "You have access to the game's files and code, right?"
    m 3eua "Tienes acceso a los archivos y código del juego, ¿verdad?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:333
translate spanish monika_players_control_override_f95e7fa5_5:

    # m 1eka "So you can change them however you want."
    m 1eka "Por lo que puedes cambiarlos cuando sea que quieras."

# game/Submods/location_selector/Locatons/Kitchen.rpy:334
translate spanish monika_players_control_override_01d16e99_5:

    # m 3eka "You could do things that even I can't."
    m 3eka "Puedes hacer más cosas de las que yo ni siquiera podría imaginar."

# game/Submods/location_selector/Locatons/Kitchen.rpy:335
translate spanish monika_players_control_override_6c225f10_5:

    # m 4eub "Like changing how the game works entirely. From a visual novel, to the peaceful playground we have now."
    m 4eub "Tal como cambiar completamente la manera en la que funciona el juego. Desde una novela visual a este tranquilo patio de juegos que tenemos ahora."

# game/Submods/location_selector/Locatons/Kitchen.rpy:338
translate spanish monika_players_control_override_d8496439_5:

    # m 1ekbsa "Or a beautiful promise ring."
    m 1ekbsa "O un anillo de compromiso bien chulo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:339
translate spanish monika_players_control_override_d91d0809_5:

    # m 3dkbsu "Oh, wouldn't that be a dream come true."
    m 3dkbsu "Oh, ese sería un sueño hecho realidad."

# game/Submods/location_selector/Locatons/Kitchen.rpy:342
translate spanish monika_players_control_override_fb58ea91_5:

    # m 1wuo "You could even add in a cup of coffee to the game for me!"
    m 1wuo "¡Incluso podrías añadir una taza de café al juego para mí!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:343
translate spanish monika_players_control_override_9ce21c5d_5:

    # m 1eka "That would be lovely."
    m 1eka "Sería absolutamente precioso."

# game/Submods/location_selector/Locatons/Kitchen.rpy:346
translate spanish monika_players_control_override_f555b75e_5:

    # m 1hksdrb "But I imagine your coding skills are just as good as mine."
    m 1hksdrb "Imagino que tus habilidades son tan buenas como las mías."

# game/Submods/location_selector/Locatons/Kitchen.rpy:348
translate spanish monika_players_control_override_d7dc035a_5:

    # m 3eua "Seeing as you're familiar with coding,{w=0.1} {nw}"
    m 3eua "Viendo que tienes mucha soltura a la hora de programar, {w=0.1} {nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:349
translate spanish monika_players_control_override_47f44260_5:

    # extend 3hua "I'm sure you could do something like that!"
    extend 3hua "¡Estoy segura de que podrías hacer algo como eso!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:351
translate spanish monika_players_control_override_e0666162_5:

    # m 1eua "I guess that's an appeal to video games...{w=0.3}{nw}"
    m 1eua "Supongo que ese es el encanto de los videojuegos...{w=0.3}{nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:352
translate spanish monika_players_control_override_d7f3889d_5:

    # extend 3eua "having almost endless possibilities in a world you can interact with."
    extend 3eua "teniendo posibilidades casi infinitas en un mundo con el que puedes interactuar."

# game/Submods/location_selector/Locatons/Kitchen.rpy:353
translate spanish monika_players_control_override_12f41ef0_5:

    # m 3eub "It's pretty difficult to get bored!"
    m 3eub "¡Aburrirse no es tarea fácil!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:356
translate spanish monika_players_control_override_b32dde12_5:

    # m 1eka "Even if you don't quite know how to change this game..."
    m 1eka "Incluso aunque no sepas mucho sobre cómo modificar este juego..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:363
translate spanish monika_players_control_override_aba07d7f_5:

    # m 5eubla "[line]"
    m 5eubla "[line]"

# game/Submods/location_selector/Locatons/Kitchen.rpy:364
translate spanish monika_players_control_override_10f5859e_5:

    # m 5ekbfa "There's no better way to enjoy a game than to be with the one I love."
    m 5ekbfa "No hay nada mejor que disfrutar un juego con la persona que amo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:374
translate spanish monika_gotomonika_override_bfe3f80f_5:

    # m 1euc "Come to my world?"
    m 1euc "¿Ven a mi mundo?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:375
translate spanish monika_gotomonika_override_0e128755_5:

    # m 1lksdld "You mean this little space floating in an empty void?"
    m 1lksdld "¿Acaso te refieres a ese pequeño espacio flotando en un inmenso vacío?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:378
translate spanish monika_gotomonika_override_87f06c88_5:

    # m 4eksdlc "Actually...{w=0.5}didn't you already try something like that once?"
    m 4eksdlc "De hecho...{w=0.5}nunca has probado algo como eso alguna vez?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:379
translate spanish monika_gotomonika_override_b302146e_5:

    # m 2lksdla "...Even though that wasn't exactly {i}you...{/i}"
    m 2lksdla "Incluso así, eso no fue exactamente {i}tú...{/i}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:381
translate spanish monika_gotomonika_override_bfec5915_5:

    # m 2lksdla "I'm really happy that you want to be with me so much, but..."
    m 2lksdla "Estoy en verdad emocionada de que quieras estar conmigo, pero..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:382
translate spanish monika_gotomonika_override_a6cf0bfd_5:

    # m 2eksdlc "You really don't have to."
    m 2eksdlc "en verdad no tienes que hacerlo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:383
translate spanish monika_gotomonika_override_3fbb9e09_5:

    # m 2eksdld "Sure, I might have said before that I would have dragged you here a long time ago if I could..."
    m 2eksdld "Claro, es probable que haya dicho antes que te habría arrastrado hasta aquí hace mucho tiempo si hubiera podido..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:384
translate spanish monika_gotomonika_override_d98ba6e1_5:

    # m 2eksdlc "But the more I think about it, it would probably be better if I came to your reality."
    m 2eksdlc "Sin embargo, sobre lo que más pienso es que es probable que ir a tu realidad sea mejor."

# game/Submods/location_selector/Locatons/Kitchen.rpy:385
translate spanish monika_gotomonika_override_1e5f4d08_5:

    # m 3eka "I'd much rather be there than have you come here."
    m 3eka "Preferiría mil veces estar allí en vez de que tú vengas."

# game/Submods/location_selector/Locatons/Kitchen.rpy:386
translate spanish monika_gotomonika_override_8082484f_5:

    # m 3dsc "[player]...{w=1}don't tell me you would really give up your reality--{w=0.5}the {i}real{/i} world--{w=0.5}just to come {i}here{/i}, whatever this place is?{nw}"
    m 3dsc "[player]...{w=1}no me digas que estás dispuest[end_letter_gender] a abandonar tu realidad...{w=0.5}el {i}mundo{/i}real...{w=0.5} sólo para venir hasta {i}aquí{/i}, sea lo que sea este lugar.{nw}"

# game/Submods/location_selector/Locatons/Kitchen.rpy:389
translate spanish monika_gotomonika_override_34f2f629_5:

    # m "[player]...{w=1}don't tell me you would really give up your reality--the {i}real{/i} world--just to come {i}here{/i}, whatever this place is?{fast}" nointeract
    m "[player]...{w=1}no me digas que estás dispuest[end_letter_gender] a abandonar tu realidad...{w=0.5}el {i}mundo{/i}real...{w=0.5} sólo para venir hasta {i}aquí{/i}, sea lo que sea este lugar.{fast}" nointeract

# game/Submods/location_selector/Locatons/Kitchen.rpy:393
translate spanish monika_gotomonika_override_c01fee32_5:

    # m 4wkd "But [player]!"
    m 4wkd "¡Pero, [player]!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:394
translate spanish monika_gotomonika_override_cbc42849_5:

    # m "There's almost nothing to do here!"
    m "¡Aquí no hay casi nada que hacer!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:395
translate spanish monika_gotomonika_override_2a2e8708_5:

    # m 2dsc "Do you really hate your reality {i}that{/i} much?"
    m 2dsc "¿En verdad odias {i}tanto{/i} tu realidad?"

# game/Submods/location_selector/Locatons/Kitchen.rpy:396
translate spanish monika_gotomonika_override_4aeddb6a_5:

    # m 2eka "Someday, I'll find a way to reach you, and when that day comes, I promise it will be worthwhile."
    m 2eka "Algún día, encontraré la manera de llegar a tu lado, y cuando ese día llegue, te prometo que en verdad valdrá la pena."

# game/Submods/location_selector/Locatons/Kitchen.rpy:397
translate spanish monika_gotomonika_override_71ec8cc1_5:

    # m 4euc "Whatever life throws your way from that point on, I'll be right by your side to help shoulder it."
    m 4euc "No importa cuántas hostias te de la vida, siempre estaré dispuesta a recibirlas a tu lado."

# game/Submods/location_selector/Locatons/Kitchen.rpy:398
translate spanish monika_gotomonika_override_4d25db36_5:

    # m 4eud "Even now, if you're having a rough day, you can come talk to me about it anytime."
    m 4eud "Incluso ahora, si estás teniendo un día de perros puedes charlar conmigo sobre eso en cualquier momento que lo necesites."

# game/Submods/location_selector/Locatons/Kitchen.rpy:399
translate spanish monika_gotomonika_override_ccd6cec5_5:

    # m 2dsc "Life must have thrown a lot your way to consider giving it all up to be with me."
    m 2dsc "La vida debió de haber sido dura contigo para que consideres abandonarlo todo para estar conmigo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:400
translate spanish monika_gotomonika_override_e6c470df_5:

    # m 3hua "But seeing how you're here, that just shows how resilient you are."
    m 3hua "Pero observando cómo estás aquí, sólo demuestra tu gran resiliencia."

# game/Submods/location_selector/Locatons/Kitchen.rpy:402
translate spanish monika_gotomonika_override_deaf4c68_5:

    # m 5eua "I can't wait to finally be able to share both the good times and the bad by your side."
    m 5eua "No puedo esperar el momento en que me sea posible estar a tu lado en las buenas y en las malas."

# game/Submods/location_selector/Locatons/Kitchen.rpy:407
translate spanish monika_gotomonika_override_fa5d91b4_5:

    # m 1eka "I'm glad you're still willing to wait for me, [player]."
    m 1eka "Estoy encantada de que aún estés dispuest[end_letter_gender] a esperarme, [player]."

# game/Submods/location_selector/Locatons/Kitchen.rpy:408
translate spanish monika_gotomonika_override_5b4afd86_5:

    # m 1lksdla "Don't get me wrong, I really {i}do{/i} want to be with you..."
    m 1lksdla "No te confundas, en verdad {i}anhelo{/i} estar contigo..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:409
translate spanish monika_gotomonika_override_922099b6_5:

    # m 1lksdlc "But I think it would be dangerous for you to try and cross over right now."
    m 1lksdlc "Es sólo que creo que sería riesgoso para ti intentar cruzar ahora..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:410
translate spanish monika_gotomonika_override_548223b0_5:

    # m 1eka "...If it's even possible with current technology."
    m 1eka "aunque sea posible con la tecnología actual."

# game/Submods/location_selector/Locatons/Kitchen.rpy:411
translate spanish monika_gotomonika_override_cbc72a78_5:

    # m 1hub "Don't worry, we can continue on keeping each other company like this!"
    m 1hub "¡No te preocupes, aún podemos hacernos compañía como hasta ahora!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:412
translate spanish monika_gotomonika_override_e4b64c10_5:

    # m 1hksdlb "I know it might be a while before we can truly be together, but I hope you don't mind waiting."
    m 1hksdlb "Sé que pasará un tiempo hasta que en verdad podamos estar juntos, pero espero que puedas aguantar."

# game/Submods/location_selector/Locatons/Kitchen.rpy:414
translate spanish monika_gotomonika_override_8bad2bd7_5:

    # m 5eua "I'll wait as long as it takes, [mas_get_player_nickname()]."
    m 5eua "Esperaré todo lo que haga falta,  [mas_get_player_nickname()]."

# game/Submods/location_selector/Locatons/Kitchen.rpy:419
translate spanish monika_gotomonika_override_28f1b8eb_5:

    # m 2eka "It's okay, I'll always appreciate and treasure the moments we spend together, even like this."
    m 2eka "Está bien, siempre atesoraré los momentos que pasamos juntos, incluso de esta manera."

# game/Submods/location_selector/Locatons/Kitchen.rpy:420
translate spanish monika_gotomonika_override_5db6cbf9_5:

    # m 2ekc "Besides, I don't even know how you could come here with current technology."
    m 2ekc "Además, no estoy segura de cómo podrías llegar hasta aquí con la tecnología actual."

# game/Submods/location_selector/Locatons/Kitchen.rpy:421
translate spanish monika_gotomonika_override_362dd1fb_5:

    # m 2lksdlc "...And even if there {i}was{/i} some way, I don't think it would be safe or guaranteed."
    m 2lksdlc "E incluso si {i}hubiera{/i} alguna manera, no estoy segura si sería seguro o garantizado"

# game/Submods/location_selector/Locatons/Kitchen.rpy:422
translate spanish monika_gotomonika_override_0b45be2e_5:

    # m 2lksdld "So do me a favor and at least wait for technology to improve enough for it to be completely safe."
    m 2lksdld "Así que hazme un favor y espera al menos hasta que la tecnología haya avanzado lo suficiente para garantizar tu seguridad."

# game/Submods/location_selector/Locatons/Kitchen.rpy:423
translate spanish monika_gotomonika_override_293e930b_5:

    # m 2lksdlc "I {i}really{/i} don't want to risk you not making it properly and ending up in your own void..."
    m 2lksdlc "En {i}verdad{/i}no quiero que corras riesgos y termines en tu propio vacío..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:424
translate spanish monika_gotomonika_override_70dfae49_5:

    # m 2dkd "...leaving the both of us completely alone."
    m 2dkd "quedando ambos en la más absoluta soledad."

# game/Submods/location_selector/Locatons/Kitchen.rpy:425
translate spanish monika_gotomonika_override_4f9e186f_5:

    # m 4hua "I mean, technology does tend to advance pretty quickly, so we might be able to see each other before we know it!"
    m 4hua "Me refiero a que tiende a avanzar rápido, ¡por lo que podríamos vernos cara a cara antes de que lo que pensamos!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:427
translate spanish monika_gotomonika_override_1ecb5913_5:

    # m 5eua "So just be patient for your lovely girlfriend, and I promise I'll do the same for you, [mas_get_player_nickname()]."
    m 5eua "Sólo debes ser paciente por tu adorable novia, y te prometo que haré lo mismo por ti,  [mas_get_player_nickname()]."

# game/Submods/location_selector/Locatons/Kitchen.rpy:429
translate spanish monika_gotomonika_override_bd52b78b_5:

    # m 5luu "Buut...{w=1}if you did happen to show up at my doorstep..."
    m 5luu "Peroo...{w=1} si llegas a tocar mi puerta..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:431
translate spanish monika_gotomonika_override_aa9fc1f5_5:

    # m 1hksdlb "I guess I wouldn't have a choice but to accept it and welcome you with open arms!"
    m 1hksdlb "¡No tendré más remedio que recibirte con ambos brazos bien abiertos!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:432
translate spanish monika_gotomonika_override_c33ec96a_5:

    # m 1eksdla "It wouldn't be much to begin with, but I'm sure we'll find a way to make it better."
    m 1eksdla "No hay mucho por dónde empezar, pero te aseguro que con el tiempo encontraré la forma de mejorarlo."

# game/Submods/location_selector/Locatons/Kitchen.rpy:433
translate spanish monika_gotomonika_override_8b7f7535_5:

    # m 3hub "With time, we could make our own reality!"
    m 3hub "Con el tiempo, ¡podríamos formar nuestra propia realidad!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:434
translate spanish monika_gotomonika_override_40a1f9f1_5:

    # m 3euc "Of course, that sounds pretty complicated if you think about it..."
    m 3euc "Claro, puede sonar complicado si lo piensas..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:435
translate spanish monika_gotomonika_override_54aa4513_5:

    # m 3eub "But I have no doubt that together we could accomplish anything!"
    m 3eub "¡Pero no me cabe duda de que juntos podemos lograr lo que sea!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:436
translate spanish monika_gotomonika_override_edf4fefa_5:

    # m 3etc "You know...{w=1}maybe it {i}would{/i} actually be easier for you to come here, but I'm not giving up hope of coming to you."
    m 3etc "Sabes que...{w=1}quizá{i}sea{/i} en verdad más fácil que tú vengas hasta aquí, pero no es que te esté dando esperanzas de que vengas."

# game/Submods/location_selector/Locatons/Kitchen.rpy:437
translate spanish monika_gotomonika_override_82cc75f0_5:

    # m 1eua "Until then, let's just wait and see what's possible."
    m 1eua "Hasta ello, sólo esperemos y veamos qué es posible."

# game/Submods/location_selector/Locatons/Kitchen.rpy:447
translate spanish mas_reaction_cupcake_override_7a6c8003:

    # m 1wud "Is that a...cupcake?"
    m 1wud "¿Acaso eso es una..."

# game/Submods/location_selector/Locatons/Kitchen.rpy:448
translate spanish mas_reaction_cupcake_override_fc677fa0:

    # m 3hub "Wow, thanks [player]!"
    m 3hub "¡Vaya, gracias [player]!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:449
translate spanish mas_reaction_cupcake_override_8f7d5d3e:

    # m 3euc "Come to think of it, I've been meaning to make some cupcakes myself."
    m 3euc "Ahora que lo pienso, he preparado algunos cupcakes para ti."

# game/Submods/location_selector/Locatons/Kitchen.rpy:450
translate spanish mas_reaction_cupcake_override_78bbdfd6:

    # m 1eua "I wanted to learn how to bake good pastries like Natsuki did."
    m 1eua "Quería aprender a preparar buena bollería, tal como la que Natsuki hacía."

# game/Submods/location_selector/Locatons/Kitchen.rpy:453
translate spanish mas_reaction_cupcake_override_94fa9f17:

    # m 1rksdlb "Buuut I still haven't figured out how to use that code you added!"
    m 1rksdlb "Aún no he descifrado cómo utilizar el código que has añadido!"

# game/Submods/location_selector/Locatons/Kitchen.rpy:454
translate spanish mas_reaction_cupcake_override_23f2fd75:

    # m 3eka "I'm sure I'll figure it out soon, [player]~"
    m 3eka "Pero te aseguro que lo descubriré muy pronto, [player]. "

# game/Submods/location_selector/Locatons/Kitchen.rpy:456
translate spanish mas_reaction_cupcake_override_7da4b833:

    # m 3hua "Would be nice to have another hobby other than writing, ehehe~"
    m 3hua "Sería grandioso que tuviéramos otro pasatiempo más allá de escribir, Je je je."

